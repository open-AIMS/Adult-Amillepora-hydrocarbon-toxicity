#==== Load packages ===============

require(cmdstanr)
set_cmdstan_path("C:/cmdstan")
options(brms.backend = "cmdstanr")
library(bayesnec)
library(brms)
require(graphics)

library(readxl)
library(ggplot2)
library(tidyverse)
library(dplyr)

#-------Static experiment -----------------------        

Max.dat <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\Surv_data.xlsx", 
                      sheet = "Max")

Max.dat.use <- Max.dat %>%
  dplyr::select(5,16) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(Prop96*20),
                x=sqrt(T4d_Max),
                Tot = as.integer(20)) %>%
  data.frame() 

Max.out <- bnec(Suc | trials(Tot) ~ crf((x), model = "decline"),
                data=Max.dat.use,
                family = beta_binomial2,
                control = list(adapt_delta = 0.99), iter = 10000)

autoplot(Max.out, all_models = TRUE)
summary(Max.out)

check_chains(Max.out, filename = "Max_all_chains")
check_priors(Max.out$mod_fits$ecxll3)#ecxll3 best fit
check_priors(Max.out, filename = "Max_all_priors")

rhat(Max.out, rhat_cutoff = 1.05)
#no models failed
#chain mixing looked adequate

Max.EC10 <- ecx(Max.out, ecx_val = 10)
Max.EC10^2

Max.EC50 <- ecx(Max.out, ecx_val = 50)
Max.EC50^2

#Plot Max.out

Max.preds <- Max.out$w_pred_vals$data
Max.pred.vals <- Max.out$w_pred_vals

pred.Max <- data.frame(up = Max.pred.vals$data$Q97.5, 
                       lw = Max.pred.vals$data$Q2.5, 
                       x = Max.pred.vals$data$x, 
                       y = Max.pred.vals$data$Estimate)

Max.p0 <- ggplot() +
  geom_point(data = Max.dat.use, aes(x = x, y = Prop96, alpha = 0.10))

Max.p1 <- Max.p0 + theme_classic() +
  geom_vline(mapping = aes(xintercept = Max.EC10), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = Max.EC50), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue", "NEC" = "tomato"), name = "") +
  geom_line(data = Max.preds, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = Max.preds, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = Max.preds, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  theme(axis.title.y = element_text(size = 14),
        axis.title.x = element_text(size=14),
        axis.text = element_text(size = 10), 
        strip.text.x = element_blank()) + 
  ylim(c(0,1.05)) + 
  labs(x = "1-methylnaphthalene"~({mu*g~L^-1}), y = "Prop. of survivorship") + 
  scale_x_continuous(breaks = sqrt(c(0, 300, 1000, 3000, 10000)), 
                     labels = c("0", "300", "1000", "3000", "10000")) + 
  theme(legend.position = "none") + 
  geom_ribbon(aes(x = pred.Max$x, ymin = pred.Max$lw, ymax = pred.Max$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 11),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9))

Max.p1
ggsave(filename="MaxCR.png", plot=Max.p1, height = 2, width=3.25, units=c("in"), dpi=300)

save(Max.out, Max.EC10, Max.EC50, Max.NEC, file = "Output.Max.RData")
load("Output.Max.RData")         

