#==== Load packages ===============

library(readxl)
library(ggplot2)
library(tidyverse)
library(dplyr)


#--- Spectrum graph -----
Spectrum.data <- read.csv('Spectrum.csv', strip.white = T)%>%
  data.frame() 

str(Spectrum.data)

spectrum.p <- ggplot(Spectrum.data, aes(x=Wavelength, y=AbsIrr)) + geom_line(size = 1) + 
  labs(x="Wavelength (nm)", y="Absolute irradiance"~({mu*W~cm^-2~nm^-1})) 

spectrum.p 

ggsave(filename="Spectrum.png", plot=spectrum.p, height = 4, width = 7, units=c("in"), dpi=300)


