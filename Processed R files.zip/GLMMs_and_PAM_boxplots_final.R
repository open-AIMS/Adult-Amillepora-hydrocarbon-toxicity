#==== Load packages ===============

require(cmdstanr)
set_cmdstan_path("C:/cmdstan")
options(brms.backend = "cmdstanr")
library(bayesnec)
library(brms)
require(graphics)

library(readxl)
library(ggplot2)
library(tidyverse)
library(dplyr)
library(cowplot)

library(multcomp)
library(DescTools)

library(gridExtra)
library(lattice)
library(grid)

library(nlme)
library(lme4) # for lmer
library(glmmTMB)
library(DHARMa)
library(car)       #for regression diagnostics
library(broom)     #for tidy output
library(broom.mixed) ## for tidying mixed effects models
library(ggfortify) #for model diagnostics
library(sjPlot)    #for outputs
library(effects)   #for partial effects plots
library(emmeans)   #for estimating marginal means
library(ggeffects)  #for partial effects plots
library(MASS)      #for glm.nb
library(MuMIn)
library(rstan)
library(lindia)

#glmmTMB analysis---

#UV vs PAR -----
Surv.1mn.dat.new <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\Surv_data.xlsx", 
                               sheet = "1mn.new")

UV.1mn.dat <- Surv.1mn.dat.new %>% 
  dplyr::select(1,2,4,5,10,24) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(T7_surv*100),
                Tot = as.integer(100),
                Replicate = factor(Replicate),
                Light = factor(Light),
                Treatment = as.factor(T7d_1mn)) %>% 
  data.frame

light.glmmTMB.FALSE <- glmmTMB(T7_surv ~ T7d_1mn + Light + (1|Replicate),
                               data = UV.1mn.dat,
                               family = betabinomial(link = "logit"),
                               REML = FALSE, #using FALSE since only one random effect and random effect is nested in chamber
                               control = glmmTMBControl(
                                 optimizer = optim,
                                 optArgs = list(method = "BFGS")))

light.resid.FALSE <- light.glmmTMB.FALSE %>% simulateResiduals(plot = TRUE, integerResponse = FALSE)
summary(light.glmmTMB.FALSE)

light.glmmTMB2 <- glmmTMB(T7_surv ~ T7d_1mn * Light + (1|Replicate),
                          data = UV.1mn.dat,
                          family = betabinomial(link = "logit"),
                          REML = FALSE, #using FALSE since only one random effect and random effect is nested in chamber
                          control = glmmTMBControl(
                            optimizer = optim,
                            optArgs = list(method = "BFGS")))

AICc(light.glmmTMB.FALSE, light.glmmTMB2)
#                     df     AICc
# light.glmmTMB.FALSE  5 35.80677
# light.glmmTMB2       6 37.89708

#use the simpler model - first fit

#DMSO check -----

control.data.test <- read.csv('1_mn_redo.csv', strip.white = T) %>% 
  na.omit() %>% 
  dplyr::mutate(Replicate = factor(Replicate),
                Light = factor(Light),
                fTreatment = factor(Treatment),
                fRep = factor(Rep),
                Propsurv2 = as.integer(ifelse(PropSurv >=0.95,1,PropSurv)),#most survivorship data was >0.95 so changed to 1
                Tot = as.integer(1)) %>% 
  data.frame()

control.glmmTMB.test <- glmmTMB(Propsurv2 ~ Treatment + (1|Rep), 
                                data = control.data.test,
                                family = binomial(link="logit"))

summary(control.glmmTMB.test)
control.resid <- control.glmmTMB.test %>% simulateResiduals(plot = TRUE, integerResponse = FALSE)

#scatterplot
ggplot(data = control.data.test, aes(x=Treatment, y = PropSurv, fill = Treatment)) + geom_boxplot() + theme_classic()

#Colour: Toluene-----
Colour.tol.dat <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\Surv_data.xlsx", 
                             sheet = "tol_colour_") %>% 
  na.omit() %>% 
  dplyr::mutate(Replicate = factor(Replicate),
                Time = factor(Time),
                mTreatment = factor(Treatment))

Colour.tol.glmmTMB <- glmmTMB(ColourScore ~ Treatment * Time + (1|Replicate),
                              data = Colour.tol.dat,
                              family = Gamma(link = 'log'),
                              control = glmmTMBControl(
                                optimizer = optim,
                                optArgs = list(method = "BFGS")))



colour.tol.resid <- Colour.tol.glmmTMB %>% simulateResiduals(plot = TRUE, integerResponse = FALSE)
summary(Colour.tol.glmmTMB)


#Colour: Naph----
Colour.naph.dat <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\Surv_data.xlsx", 
                              sheet = "naph_colour_") %>% 
  na.omit() %>% 
  dplyr::mutate(Replicate = factor(Replicate),
                Time = factor(Time),
                mTreatment = factor(Treatment))

Colour.naph.glmmTMB.gamma <- glmmTMB(ColourScore ~ Treatment * Time + (1|Replicate),
                                     data = Colour.naph.dat,
                                     family = Gamma(link = 'log'),
                                     REML = TRUE,
                                     control = glmmTMBControl(
                                       optimizer = optim,
                                       optArgs = list(method = "BFGS")))
colour.naph.resid <- Colour.naph.glmmTMB.gamma %>% simulateResiduals(plot = TRUE, integerResponse = FALSE)
#DHARMA residuals not great
summary(Colour.naph.glmmTMB.gamma)

#Colour: 1-MN----

Colour.1mn.dat <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\Surv_data.xlsx", 
                             sheet = "1mn_colour_") %>% 
  na.omit() %>% 
  dplyr::mutate(Replicate = factor(Replicate),
                Time = factor(Time),
                mTreatment = factor(Treatment))

head(Colour.1mn.dat)

Colour.1mn.glmmTMB <- glmmTMB(ColourScore ~ Treatment * Time + (1|Replicate),
                              data = Colour.1mn.dat,
                              family = Gamma(link = 'log'),
                              REML = TRUE,
                              control = glmmTMBControl(
                                optimizer = optim,
                                optArgs = list(method = "BFGS")))


colour.1mn.resid <- Colour.1mn.glmmTMB %>% simulateResiduals(plot = TRUE, integerResponse = FALSE)
#DHARMa residuals look fine
summary(Colour.1mn.glmmTMB)

#EQY: Toluene----

PAMlight.tol.data <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\T7_PAM.xlsx", 
                                sheet = "tol_light_T7") %>% 
  na.omit() %>% 
  dplyr::mutate(Replicate = factor(Replicate),
                mTreatment = factor(Treatment))

ggplot(data = PAMlight.tol.data, aes(x=mTreatment, y = Yield, fill = mTreatment)) + 
  geom_boxplot() 

EQY.tol.glmmTMB <- glmmTMB(Yield ~ Treatment + (1|Replicate),
                           data = PAMlight.tol.data,
                           family = beta_family(link = 'logit'),
                           control = glmmTMBControl(
                             optimizer = optim,
                             optArgs = list(method = "BFGS")))

EQY.tol.resid <- EQY.tol.glmmTMB %>% simulateResiduals(plot = TRUE, integerResponse = FALSE)
summary(EQY.tol.glmmTMB)

#MQY: Toluene----

PAMdark.tol.data <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\T7_PAM.xlsx", 
                               sheet = "tol_dark_T7") %>% 
  na.omit() %>% 
  dplyr::mutate(Replicate = factor(Replicate),
                mTreatment = factor(Treatment))

ggplot(data = PAMdark.tol.data, aes(x=mTreatment, y = Yield, fill = mTreatment)) + 
  geom_boxplot() 

MQY.tol.glmmTMB <- glmmTMB(Yield ~ Treatment + (1|Replicate),
                           data = PAMdark.tol.data,
                           family = beta_family(link = 'logit'),
                           control = glmmTMBControl(
                             optimizer = optim,
                             optArgs = list(method = "BFGS")))

MQY.tol.resid <- MQY.tol.glmmTMB %>% simulateResiduals(plot = TRUE, integerResponse = FALSE)
summary(MQY.tol.glmmTMB)

#EQY: Naph----

PAMlight.naph.data <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\T7_PAM.xlsx", 
                                 sheet = "naph_light_T7") %>% 
  na.omit() %>% 
  dplyr::mutate(Replicate = factor(Replicate),
                mTreatment = factor(Treatment)) %>% 
  data.frame()

ggplot(data = PAMlight.naph.data, aes(x=mTreatment, y = Yield, fill = mTreatment)) + 
  geom_boxplot() 

EQY.naph.glmmTMB <- glmmTMB(Yield ~ Treatment + (1|Replicate),
                            data = PAMlight.naph.data,
                            family = beta_family(link = 'logit'),
                            control = glmmTMBControl(
                              optimizer = optim,
                              optArgs = list(method = "BFGS")))

EQY.naph.resid <- EQY.naph.glmmTMB %>% simulateResiduals(plot = TRUE, integerResponse = FALSE)
summary(EQY.naph.glmmTMB)

#MQY: Naph----

PAMdark.naph.data <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\T7_PAM.xlsx", 
                                sheet = "naph_dark_T7") %>% 
  na.omit() %>% 
  dplyr::mutate(Replicate = factor(Replicate),
                mTreatment = factor(Treatment))

ggplot(data = PAMdark.naph.data, aes(x=mTreatment, y = Yield, fill = mTreatment)) + 
  geom_boxplot() 

MQY.naph.glmmTMB <- glmmTMB(Yield ~ Treatment + (1|Replicate),
                            data = PAMdark.naph.data,
                            family = beta_family(link = 'logit'),
                            control = glmmTMBControl(
                              optimizer = optim,
                              optArgs = list(method = "BFGS")))

MQY.naph.resid <- MQY.naph.glmmTMB %>% simulateResiduals(plot = TRUE, integerResponse = FALSE)
summary(MQY.naph.glmmTMB)

#EQY: 1-MN----

PAMlight.1mn.data <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\T7_PAM.xlsx", 
                                sheet = "1-mn_light_T7") %>% 
  na.omit() %>% 
  dplyr::mutate(Replicate = factor(Replicate),
                mTreatment = factor(Treatment))

ggplot(data = PAMlight.1mn.data, aes(x=mTreatment, y = Yield, fill = mTreatment)) + 
  geom_boxplot() 

EQY.1mn.glmmTMB <- glmmTMB(Yield ~ Treatment + (1|Replicate),
                           data = PAMlight.1mn.data,
                           family = beta_family(link = 'logit'),
                           control = glmmTMBControl(
                             optimizer = optim,
                             optArgs = list(method = "BFGS")))

EQY.1mn.resid <- EQY.1mn.glmmTMB %>% simulateResiduals(plot = TRUE, integerResponse = FALSE)
summary(EQY.1mn.glmmTMB)


#MQY: 1-MN-----
PAMdark.1mn.data <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\T7_PAM.xlsx", 
                               sheet = "1-mn_dark_T7") %>% 
  na.omit() %>% 
  dplyr::mutate(Replicate = factor(Replicate),
                mTreatment = factor(Treatment))

ggplot(data = PAMdark.1mn.data, aes(x=mTreatment, y = Yield, fill = mTreatment)) + 
  geom_boxplot() 

MQY.1mn.glmmTMB <- glmmTMB(Yield ~ Treatment + (1|Replicate),
                           data = PAMdark.1mn.data,
                           family = beta_family(link = 'logit'),
                           control = glmmTMBControl(
                             optimizer = optim,
                             optArgs = list(method = "BFGS")))

MQY.1mn.resid <- MQY.1mn.glmmTMB %>% simulateResiduals(plot = TRUE, integerResponse = FALSE)
summary(MQY.1mn.glmmTMB)


#PAM boxplots figures ----
#toluene PAM boxplots
tol.EQY.plot <- ggplot(PAMlight.tol.data, aes(x=mTreatment, y=Yield, fill=mTreatment)) + 
  theme_classic()+
  geom_boxplot()+ 
  theme(axis.title.y = element_text(size = 14),
        axis.title.x = element_text(size=14),
        axis.text = element_text(size = 10), 
        strip.text.x = element_blank()) + 
  ylim(c(0,0.74)) + 
  labs(x = expression("Toluene"~(mu*g~L^{-1})),
       y = expression(Delta*"F/F"[m]~"'")) + 
  theme(legend.position = "none") +
  scale_fill_brewer(palette = "YlOrRd")

tol.EQY.plot

tol.MQY.plot <- ggplot(PAMdark.tol.data, aes(x=mTreatment, y=Yield, fill=mTreatment)) +
  theme_classic() +
  geom_boxplot()+ 
  theme(axis.title.y = element_text(size = 14),
        axis.title.x = element_text(size=14),
        axis.text = element_text(size = 10), 
        strip.text.x = element_blank()) + 
  ylim(c(0,0.74)) + 
  labs(x = expression("Toluene"~(mu*g~L^{-1})),
       y = expression("F"[v]/"F"[m])) +
  theme(legend.position = "none") +
  scale_fill_brewer(palette = "YlOrRd")

tol.MQY.plot


#naphthalene boxplots

naph.EQY.plot <- ggplot(PAMlight.naph.data , aes(x=mTreatment, y=Yield, fill=mTreatment)) +theme_classic() +
  geom_boxplot()+ 
  theme(axis.title.y = element_text(size = 14),
        axis.title.x = element_text(size=14),
        axis.text = element_text(size = 10), 
        strip.text.x = element_blank()) + 
  ylim(c(0,0.74)) + 
  labs(x = expression("Naphthalene"~(mu*g~L^{-1})),
       y = expression(Delta*"F/F"[m]~"'")) + 
  theme(legend.position = "none") +
  scale_fill_brewer(palette = "YlOrRd") 

naph.EQY.plot 

naph.MQY.plot <- ggplot(PAMdark.naph.data, aes(x=mTreatment, y=Yield, fill=mTreatment)) +
  theme_classic() +
  geom_boxplot()+ 
  theme(axis.title.y = element_text(size = 14),
        axis.title.x = element_text(size=14),
        axis.text = element_text(size = 10), 
        strip.text.x = element_blank()) + 
  ylim(c(0,0.74)) + 
  labs(x = expression("Naphthalene"~(mu*g~L^{-1})),
       y = expression("F"[v]/"F"[m])) + 
  theme(legend.position = "none") +
  scale_fill_brewer(palette = "YlOrRd")

naph.MQY.plot


#1-MN boxplots

mn.EQY.plot <- ggplot(PAMlight.1mn.data, aes(x=mTreatment, y=Yield, fill=mTreatment)) + 
  theme_classic()+
  geom_boxplot()+ 
  theme(axis.title.y = element_text(size = 14),
        axis.title.x = element_text(size=14),
        axis.text = element_text(size = 10), 
        strip.text.x = element_blank()) + 
  ylim(c(0,0.74)) + 
  labs(x = expression("1-methylnaphthalene"~(mu*g~L^{-1})),
       y = expression(Delta*"F/F"[m]~"'")) + 
  theme(legend.position = "none")+ 
  scale_fill_brewer(palette = "YlOrRd")

mn.EQY.plot

mn.MQY.plot <- ggplot(PAMdark.1mn.data, aes(x=mTreatment, y=Yield, fill=mTreatment))+
  theme_classic()+
  geom_boxplot()+ 
  theme(axis.title.y = element_text(size = 14),
        axis.title.x = element_text(size=14),
        axis.text = element_text(size = 10), 
        strip.text.x = element_blank()) + 
  ylim(c(0,0.74)) + 
  labs(x = expression("1-methylnaphthalene"~(mu*g~L^{-1})),
       y = expression("F"[v]/"F"[m])) + 
  theme(legend.position = "none") + 
  scale_fill_brewer(palette = "YlOrRd")

mn.MQY.plot

#combine all PAM plots -----

pCombinePAM = cowplot::plot_grid(tol.EQY.plot, tol.MQY.plot, 
                                 naph.EQY.plot, naph.MQY.plot, 
                                 mn.EQY.plot, mn.MQY.plot,  
                                 ncol=2)
ggsave(filename="PAM_all.png", plot=pCombinePAM, height = 8, width = 8, units=c("in"), dpi=300)

