# --- Load packages ----

require(ssdtools)
library(ggplot2)
library(tidyverse)

#--79 spp -----

pch.vec <- c(17, 2, 15, 1)

data <- read.csv("CTLBBs.csv") %>%
  data.frame() %>%
  mutate(log.Conc=log..CL.., 
         log.Conc.lw=log.Conc-SE..log..CL...,
         log.Conc.up=log.Conc+SE..log..CL...,         
         Conc=10^log.Conc,
         Conc.lw=10^log.Conc.lw,
         Conc.up=10^log.Conc.up,
         Species=if_else(Classification=="Fish", "Fish", "other"),
         Species=if_else(Classification=="Microalgae" | Classification=="Phytoplankton", "Algae", Species),
         Species=if_else(str_detect(ï..Species, "Daphnia"), "Daphnids", Species),
         Species=as.factor(Species)) %>%
  arrange(Conc) %>%
  mutate(frac=ppoints(Conc))

data$pch.vals <- pch.vec[as.numeric(factor(data$Species))]

head(data)
# fit distributions
dist <- ssd_fit_dists(data, left = 'Conc', dists = c('lnorm'))
dist

PA <- data.frame(do.call("rbind", list(
  "A. millepora: adult lethal" = c(70.3, 54, 86.6),
  "A. millepora: growth" = c(32.1, 13.3, 50.9),
  "A. cervicornis" = c(180.9, 180.3, 181.5),
  "P. divaricata" = c(619, NA, NA),
  "P. astreoides" = c(359.9, 283.4, 436.4),
  "S. siderea" = c(297.4, NA, NA),
  "S. intersepta" = c(572.2, 566.8, 577.6),
  "S. bournoni" = c(303.5, NA, NA))))
colnames(PA) <- c("Conc", "Conc.lw", "Conc.up")
PA$Study <- row.names(PA)
PA <- PA %>%
  mutate(P=signif(plnorm(q=Conc, meanlog=dist$lnorm$est["meanlog"], sdlog=dist$lnorm$est["sdlog"]) * 100, 2),
         P.lw=signif(plnorm(q=Conc.lw, meanlog=dist$lnorm$est["meanlog"], sdlog=dist$lnorm$est["sdlog"]) * 100, 2),
         P.up=signif(plnorm(q=Conc.up, meanlog=dist$lnorm$est["meanlog"], sdlog=dist$lnorm$est["sdlog"]) * 100, 2))


#write.csv(PA, file="Estimated_percent_values_final.csv")

data2 <- data %>%
  dplyr::select(Conc) %>%
  mutate(Study="McGrath") %>%
  bind_rows(PA) %>%
  arrange(Conc) %>%  
  mutate(frac=ppoints(Conc),
         int.frac=plnorm(q=Conc, meanlog=dist$lnorm$est["meanlog"], sdlog=dist$lnorm$est["sdlog"]),
         percent=signif(int.frac*100,2)) %>%
  filter(Study!="McGrath") %>%
  mutate(frac2=ppoints(Conc))


# plot distributions ------------
ssdtools::ssd_plot_cdf(dist)
# goodness of fit table
ssd_gof(dist)

# Predict values ------------------
# we recommend using nboot = 10000 in predict, although this may take several minutes to run
pred <- predict(dist, nboot = 1000, ci = TRUE)

 
hc5 <- ssd_hc(dist, percent = 5L, ci = TRUE, nboot = 1000L)

#custom plot
plot(data$Conc, data$frac, pch=NA, log="x", xlim=c(3,850), 
          xlab=expression(paste("CTLBB (", mu, "mol g"^"-1"," octanol)")),
          ylab="Percent affected (%)", yaxt="n")
axis(side = 2, at=seq(0,1, length=6), labels=seq(0,1, length=6)*100)
lines(pred$est, pred$percent/100, col="black")
polygon(c(pred$lcl,rev(pred$ucl)),
        c(pred$percent/100,rev(pred$percent/100)),
        col=adjustcolor("black",alpha=0.075),border=NA)

points(data$Conc, data$frac, pch=data$pch.vals)
points(data2$Conc, data2$P/100, pch=16, col="darkred", cex=1)
legend("bottomright", legend=tolower(levels(factor(data$Species))), pch=pch.vec, bty="n")

arrows(data2$Conc, data2$P.lw/100, data2$Conc, data2$P.up/100, length=0.05, angle=90, code=3, col="darkred")
arrows(data2$Conc.lw, data2$P/100, data2$Conc.up, data2$P/100, length=0.05, angle=90, code=3, col="darkred")

text(data2$Conc + c(130,200,210,-100,-100,140,50,90), data2$P/100, labels=data2$Study, col="darkred", pos=c(2,2,2,2,3,1,3,1), cex=0.6) #position of species label text



#ggsave(filename="79spp_withcoral.pdf", plot=p1, height = 8.35, width=3.75, units=c("in"), dpi=300)

dev.off()

#-- 36 spp ----

pch.vec <- c(17, 2, 15, 1)

data <- read.csv("CTLBBs_36spp.csv") %>%
  data.frame() %>%
  mutate(log.Conc=log.CL, 
         log.Conc.lw=log.Conc-as.numeric(SE.log.Cl),
         log.Conc.up=log.Conc+as.numeric(SE.log.Cl),         
         Conc=10^log.Conc,
         Conc.lw=10^log.Conc.lw,
         Conc.up=10^log.Conc.up,
         Species=if_else(Classification=="Fish", "Fish","other"),
         Species=if_else(Classification=="Microalgae" | Classification=="Phytoplankton", "Algae", Species),
                  Species=if_else(str_detect(ï..Species, "Daphnia"), "Daphnids", Species),
         Species=as.factor(Species)) %>%
  arrange(Conc) %>%
  mutate(frac=ppoints(Conc))

data$pch.vals <- pch.vec[as.numeric(factor(data$Species))]

head(data)
# fit distributions
dist <- ssd_fit_dists(data, left = 'Conc', dists = c('lnorm'))
dist


PA <- data.frame(do.call("rbind", list(
  "A. millepora: lethal" = c(49.6, 38.7, 60.5),#	
  "A. millepora: growth" = c(13.6, 0.1, 32))))##should really be 0 but need to figure out how to change x-axis scale so that it takes the 0
colnames(PA) <- c("Conc", "Conc.lw", "Conc.up")
PA$Study <- row.names(PA)
PA <- PA %>%
  mutate(P=signif(plnorm(q=Conc, meanlog=dist$lnorm$est["meanlog"], sdlog=dist$lnorm$est["sdlog"]) * 100, 2),
         P.lw=signif(plnorm(q=Conc.lw, meanlog=dist$lnorm$est["meanlog"], sdlog=dist$lnorm$est["sdlog"]) * 100, 2),
         P.up=signif(plnorm(q=Conc.up, meanlog=dist$lnorm$est["meanlog"], sdlog=dist$lnorm$est["sdlog"]) * 100, 2))


#write.csv(PA, file="Estimated_percent_values_36spp_final.csv")


#----

data2 <- data %>%
  dplyr::select(Conc) %>%
  mutate(Study="McGrath") %>%
  bind_rows(PA) %>%
  arrange(Conc) %>%  
  mutate(frac=ppoints(Conc),
         int.frac=plnorm(q=Conc, meanlog=dist$lnorm$est["meanlog"], sdlog=dist$lnorm$est["sdlog"]),
         percent=signif(int.frac*100,2)) %>%
  filter(Study!="McGrath") %>%
  mutate(frac2=ppoints(Conc))



# plot distributions ------------
ssdtools::ssd_plot_cdf(dist)
# goodness of fit table
ssd_gof(dist)

ggsave('fit_dist_plot.png', width = 8 , height = 6 , dpi = 300)

# Predict values ------------------
# we recommend using nboot = 10000 in predict, although this may take several minutes to run
pred <- predict(dist, nboot = 10000, ci = TRUE)


hc5 <- ssd_hc(dist, percent = 5L, ci = TRUE, nboot = 1000L)

plot(data$Conc, data$frac, log="x", xlim=c(0.1,500), 
     xlab=expression(paste("CTLBB (", mu, "mol g"^"-1"," octanol)")),
     ylab="Percent affected (%)", yaxt="n", pch=data$pch.vals)
axis(side = 2, at=seq(0,1, length=6), labels=seq(0,1, length=6)*100)
lines(pred$est, pred$percent/100, col="black")
polygon(c(pred$lcl,rev(pred$ucl)),
        c(pred$percent/100,rev(pred$percent/100)),
        col=adjustcolor("black",alpha=0.075),border=NA)

points(data2$Conc, data2$P/100, pch=16, col="darkred", cex=1)
#legend("bottomright", legend=tolower(levels(factor(data$Species))), pch=pch.vec, bty="n")

arrows(data2$Conc, data2$P.lw/100, data2$Conc, data2$P.up/100, length=0.05, angle=90, code=3, col="darkred")
arrows(data2$Conc.lw, data2$P/100, data2$Conc.up, data2$P/100, length=0.05, angle=90, code=3, col="darkred")

text(data2$Conc + c(20,-25), data2$P/100, labels=data2$Study, col="darkred", pos=c(1, 2), cex=0.6)
#text(data2$Conc + c(120,190,165,-100,-100,120,50,90), data2$P/100, labels=data2$Study, col="darkred", pos=c(2,2,2,2,3,1,3,1), cex=0.6) #position of species label text
#15, -20

#ggsave(filename="36spp_withcoral.pdf", plot=p1, height = 8.35, width=3.75, units=c("in"), dpi=300)
