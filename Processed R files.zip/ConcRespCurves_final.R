#==== Load packages ===============

require(cmdstanr)
set_cmdstan_path("C:/cmdstan")
options(brms.backend = "cmdstanr")
library(bayesnec)
library(brms)
require(graphics)

library(readxl)
library(ggplot2)
library(tidyverse)
library(dplyr)
library(cowplot)

#------1-METHYLNAPHTHALENE-------------------------------------------------------------------------------------------------------------
#below is mostly same code over and over again 

Surv.1mn.dat.v2 <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\Surv_data.xlsx", 
                              sheet = "1mn.new.v2")

## ----T1 1MN dataset using a Bernoulli distribution --------------------------
#checked scatterplot of T1 data and all 0's and 1's so will use Bernoulli distribution
#note - Bernoulli distribution out of one trial only

T1.1mn.data.v2 <- Surv.1mn.dat.v2 %>% 
  dplyr::select(6,11,18) %>% #selecting only T1 data
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(ifelse(T1_mort <= 0.05, 1, T1_surv)), #if mortality is less than or equal to 5%, then survivorship was changed to 100%
                x = sqrt(T1d_1mn))  %>% 
  as.data.frame()

T1.1mn.fit.v2 <- bnec(Suc ~ crf((x), model = "decline"),
                      data = T1.1mn.data.v2,
                      family = bernoulli(link = "identity"), 
                      iter = 10e3, control = list(adapt_delta = 0.99))

autoplot(T1.1mn.fit.v2, all_models = TRUE)
summary(T1.1mn.fit.v2)

rhat(T1.1mn.fit.v2, rhat_cutoff = 1.05)
#none failed 

check_chains(T1.1mn.fit.v2, filename = "Output/T1_1mn_v2_all_chains")
check_priors(T1.1mn.fit.v2, filename = "Output/T1_1mn_v2_all_priors")

T1.1mn.EC10.v2 <- ecx(T1.1mn.fit.v2, ecx_val = 10)
T1.1mn.EC10.v2^2
T1.1mn.EC50.v2 <- ecx(T1.1mn.fit.v2, ecx_val = 50)
T1.1mn.EC50.v2^2

#Plot T1.1mn.fit.new
T1.1mn.preds.v2 <- T1.1mn.fit.v2$w_pred_vals$data
T1.1mn.pred.vals.v2 <- T1.1mn.fit.v2$w_pred_vals
pred.T1.1mn.v2 <- data.frame(up = T1.1mn.pred.vals.v2$data$Q97.5, 
                             lw = T1.1mn.pred.vals.v2$data$Q2.5, 
                             x = T1.1mn.pred.vals.v2$data$x, 
                             y = T1.1mn.pred.vals.v2$data$Estimate)

T1.1mn.p.v2 <- ggplot() +  
  geom_point(data = T1.1mn.data.v2, aes(x = x, y = T1_surv, alpha = 0.1), 
             position = position_jitter(width = 1, height = 0), size = 0.75)

p.v2 <- T1.1mn.p.v2 + theme_classic() +
  geom_vline(mapping = aes(xintercept = T1.1mn.EC10.v2), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T1.1mn.EC50.v2), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue"), name = "") +
  geom_line(data = T1.1mn.preds.v2, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T1.1mn.preds.v2, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T1.1mn.preds.v2, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "", y = " ") + #"1-Methylnaphthalene"~({mu*g~L^-1}), y = " ")
  scale_x_continuous(breaks = sqrt(c(0, 100, 400, 1000, 2000, 4000)),                                                                                      
                     labels = c("0", "100", "400", "1000", "2000", "4000")) +
  coord_cartesian(xlim = c(-1,73), ylim=c(0,1.05)) +  
  labs(title = "T1 d") + 
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T1.1mn.v2$x, ymin = pred.T1.1mn.v2$lw, ymax = pred.T1.1mn.v2$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text.y = element_text(size = 9), 
        axis.text.x = element_blank(),
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8)) 
p.v2
ggsave(filename = "Output/1mn_1d.png", plot = p.v2, height = 1.4, width = 3, units = c("in"), dpi = 300)

save(T1.1mn.fit.v2, T1.1mn.EC10.v2, T1.1mn.EC50.v2, T1.1mn.preds.v2, T1.1mn.pred.vals.v2, pred.T1.1mn.v2, file = "Output/Output.T1.1mn.v2.RData")
load("Output/Output.T1.1mn.v2.RData")

## ---- T2 1MN dataset --------------------------------------------------------------------------------
T2.1MN.data.v2 <- Surv.1mn.dat.v2 %>% 
  dplyr::select(7,19) %>%
  na.omit() %>%
  mutate(Suc = as.integer(T2_surv*20), #accounting for 5% error in calculating mortality
         x = sqrt(T2d_1mn),
         Tot = 20)  %>% 
  as.data.frame()

set.seed(111)
T2.1MN.fit.v2 <- bnec(Suc | trials(Tot) ~ crf((x), model = "decline"),
                      data=T2.1MN.data.v2,
                      family = beta_binomial2,
                      control = list(adapt_delta = 0.99), iter = 10e3)

autoplot(T2.1MN.fit.v2, all_models = TRUE)
summary(T2.1MN.fit.v2)

rhat(T2.1MN.fit.v2, rhat_cutoff = 1.05)
# no models failed

check_chains(T2.1MN.fit.v2, filename = "Output/T2_1mn_v2_all_chains")
#chain mixing looks good for all models

check_priors(T2.1MN.fit.v2, filename = "Output/T2_1mn_v2_all_priors")

T2.1mn.EC10.v2 <- ecx(T2.1MN.fit.v2, ecx_val = 10)
T2.1mn.EC10.v2^2
#ec_10  ec_10_lw  ec_10_up 
#1283.119  930.172 1812.664 

T2.1mn.EC50.v2 <- ecx(T2.1MN.fit.v2, ecx_val = 50)
T2.1mn.EC50.v2^2
#ec_50  ec_50_lw  ec_50_up 
#2653.641 1853.561 3261.363 

#Plot T2.1mn.fit.v2
T2.1mn.preds.v2 <- T2.1MN.fit.v2$w_pred_vals$data
T2.1mn.pred.vals.v2 <- T2.1MN.fit.v2$w_pred_vals
pred.T2.1mn.v2 <- data.frame(up = T2.1mn.pred.vals.v2$data$Q97.5, 
                             lw = T2.1mn.pred.vals.v2$data$Q2.5, 
                             x = T2.1mn.pred.vals.v2$data$x, 
                             y = T2.1mn.pred.vals.v2$data$Estimate)

T2.1mn.p.v2 <- ggplot() +
  geom_point(data = T2.1MN.data.v2, aes(x = x, y = T2_surv, alpha = 0.1), 
             position = position_jitter(width = 1, height = 0), size = 0.75)

p1.v2 <- T2.1mn.p.v2 + 
  theme_classic() +
  geom_vline(mapping = aes(xintercept = T2.1mn.EC10.v2), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T2.1mn.EC50.v2), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue"), name = "") +
  geom_line(data = T2.1mn.preds.v2, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T2.1mn.preds.v2, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T2.1mn.preds.v2, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +   
  labs(x = "", y = " ") + 
  scale_x_continuous(breaks = sqrt(c(0, 100, 400, 1000, 2000, 4000)),                                                                                      
                     labels = c("0", "100", "400", "1000", "2000", "4000")) +
  coord_cartesian(xlim = c(-1,73), ylim=c(0,1.05)) +
  labs(title = "T2 d") +
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T2.1mn.v2$x, ymin = pred.T2.1mn.v2$lw, ymax = pred.T2.1mn.v2$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text.y = element_text(size = 9), 
        axis.text.x = element_blank(), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8)) 
p1.v2
ggsave(filename = "Output/1mn_2d.png", plot = p1.v2, height = 1.4, width = 3, units = c("in"), dpi = 300)

save(T2.1MN.fit.v2, T2.1mn.EC10.v2, T2.1mn.EC50.v2, T2.1mn.preds.v2, T2.1mn.pred.vals.v2, pred.T2.1mn.v2, file = "Output/Output.T2.1mn.v2.RData")
load("Output/Output.T2.1mn.v2.RData")

## -------- T3 1MN dataset ----------------------------------------------------------------------------------------

T3.1mn.data.v2 <- Surv.1mn.dat.v2 %>% 
  dplyr::select(8,20) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(T3_surv*20),
                x = sqrt(T3d_1mn), 
                Tot = 20) %>% 
  as.data.frame()

set.seed(111)
T3.1mn.fit.v2 <- bnec(Suc | trials(Tot) ~ crf((x), model = "decline"),
                      data=T3.1mn.data.v2,
                      family = beta_binomial2,
                      control = list(adapt_delta = 0.99), iter = 10e3)

autoplot(T3.1mn.fit.v2, all_models = TRUE)
summary(T3.1mn.fit.v2)

rhat(T3.1mn.fit.v2, rhat_cutoff = 1.05)
#$"nec4param"    

check_chains(T3.1mn.fit.v2, filename = "Output/T3_1mn_v2_all_chains")
#"nec4param" - poor chain mixing

check_priors(T3.1mn.fit.v2, filename = "Output/T3_1mn_v2_all_priors")

T3.1mn.fit.v2.amended <- amend(T3.1mn.fit.v2, drop = c("nec4param"))

T3.1mn.EC10.v2 <- ecx(T3.1mn.fit.v2.amended, ecx_val = 10)
T3.1mn.EC10.v2^2


T3.1mn.EC50.v2 <- ecx(T3.1mn.fit.v2.amended, ecx_val = 50)
T3.1mn.EC50.v2^2


#Plot T3.1mn.fit.v2.amended

T3.1mn.preds.v2 <- T3.1mn.fit.v2.amended$w_pred_vals$data
T3.1mn.pred.vals.v2 <- T3.1mn.fit.v2.amended$w_pred_vals

pred.T3.1mn.v2 <- data.frame(up = T3.1mn.pred.vals.v2$data$Q97.5,
                             lw = T3.1mn.pred.vals.v2$data$Q2.5, 
                             x = T3.1mn.pred.vals.v2$data$x, 
                             y = T3.1mn.pred.vals.v2$data$Estimate)

T3.1mn.p.v2 <- ggplot() +
  geom_point(data = T3.1mn.data.v2, aes(x = x, y = T3_surv, alpha = 0.10),
             position = position_jitter(width = 1, height = 0), size = 0.75)

p2.v2 <- T3.1mn.p.v2 + 
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = T3.1mn.EC10.v2), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T3.1mn.EC50.v2), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue"), name = "") +
  geom_line(data = T3.1mn.preds.v2, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T3.1mn.preds.v2, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T3.1mn.preds.v2, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "", y = "") + 
  scale_x_continuous(breaks = sqrt(c(0, 100, 400, 1000, 2000, 4000)),                                                                                      
                     labels = c("0", "100", "400", "1000", "2000", "4000")) + 
  coord_cartesian(xlim = c(-1,73), ylim=c(0,1.05)) +
  labs(title = "T3 d") + 
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T3.1mn.v2$x, ymin = pred.T3.1mn.v2$lw, ymax = pred.T3.1mn.v2$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text.y = element_text(size = 9), 
        axis.text.x = element_blank(),  
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8)) 
p2.v2
ggsave(filename = "Output/1mn_3d.png", plot = p2.v2, height = 1.4, width = 3, units = c("in"), dpi = 300)

save(T3.1mn.fit.v2, T3.1mn.fit.v2.amended, T3.1mn.EC10.v2, T3.1mn.EC50.v2, T3.1mn.preds.v2, T3.1mn.pred.vals.v2, pred.T3.1mn.v2, file = "Output/Output.T3.1mn.v2.RData")
load("Output/Output.T3.1mn.v2.RData")


## ------------------- T4 1MN dataset -----------------------------------------------------------------

T4.1mn.data.v2 <- Surv.1mn.dat.v2 %>% 
  dplyr::select(9,21) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(T4_surv*20),
                x = sqrt(T4d_1mn), 
                Tot = 20) %>% 
  as.data.frame()

set.seed(111)
T4.1mn.fit.v2 <- bnec(Suc | trials(Tot) ~ crf((x), model = "decline"),
                      data=T4.1mn.data.v2,
                      family = beta_binomial2,
                      control = list(adapt_delta = 0.99), iter = 10e3)

autoplot(T4.1mn.fit.v2, all_models = TRUE)

summary(T4.1mn.fit.v2)

rhat(T4.1mn.fit.v2, rhat_cutoff = 1.05)
#$failed none

check_chains(T4.1mn.fit.v2, filename = "Output/T4_1mn_v2_all_chains")
#chain mixing looks good

check_priors(T4.1mn.fit.v2, filename = "Output/T4_1mn_v2_all_priors")

T4.1mn.EC10.v2 <- ecx(T4.1mn.fit.v2, ecx_val = 10)
T4.1mn.EC10.v2^2

T4.1mn.EC50.v2 <- ecx(T4.1mn.fit.v2, ecx_val = 50)
T4.1mn.EC50.v2^2


#Plot T4.1mn.fit.v2

T4.1mn.preds.v2 <- T4.1mn.fit.v2$w_pred_vals$data
T4.1mn.pred.vals.v2 <- T4.1mn.fit.v2$w_pred_vals

pred.T4.1mn.v2 <- data.frame(up = T4.1mn.pred.vals.v2$data$Q97.5, 
                             lw = T4.1mn.pred.vals.v2$data$Q2.5, 
                             x = T4.1mn.pred.vals.v2$data$x, 
                             y = T4.1mn.pred.vals.v2$data$Estimate)

T4.1mn.p.v2 <- ggplot() +
  geom_point(data = T4.1mn.data.v2, aes(x = x, y = T4_surv, alpha = 0.10), 
             position = position_jitter(width = 1, height = 0), size = 0.75)

p3.v2 <- T4.1mn.p.v2 + 
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = T4.1mn.EC10.v2), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T4.1mn.EC50.v2), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue"), name = "") +
  geom_line(data = T4.1mn.preds.v2, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T4.1mn.preds.v2, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T4.1mn.preds.v2, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "", y = "Proportion of Survivorship") + 
  scale_x_continuous(breaks = sqrt(c(0, 100, 400, 1000, 2000, 4000)),                                                                                      
                     labels = c("0", "100", "400", "1000", "2000", "4000")) + 
  coord_cartesian(xlim = c(-1,73), ylim=c(0,1.05)) +
  labs(title = "T4 d") + 
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T4.1mn.v2$x, ymin = pred.T4.1mn.v2$lw, ymax = pred.T4.1mn.v2$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) + 
  theme(axis.title.y = element_text(size = 8),
        axis.title.x = element_text(size=11),
        axis.text.y = element_text(size = 9), 
        axis.text.x = element_blank(), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8))  
p3.v2
ggsave(filename = "Output/1mn_4d.png", plot = p3.v2, height = 1.4, width = 3, units = c("in"), dpi = 300)
ggsave(filename = "Output/1mn_4d.v2.png", plot = p3.v3, height = 1.4, width = 3, units = c("in"), dpi = 300)

save(T4.1mn.fit.v2, T4.1mn.EC10.v2, T4.1mn.EC50.v2, T4.1mn.preds.v2, T4.1mn.pred.vals.v2, pred.T4.1mn.v2, file = "Output/Output.T4.1mn.v2.RData")
load("Output/Output.T4.1mn.v2.RData")


##---- T7 1MN dataset ----------------------------------------------
T7.1mn.data.v2 <- Surv.1mn.dat.v2 %>% 
  dplyr::select(1,5, 10,24) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(T7_surv*20), 
                x = sqrt(T7d_1mn),
                Tot = as.integer(20),
                Tank = as.factor(Chamber), 
                Rep = as.factor(Replicate)) %>% 
  as.data.frame()

set.seed(123)
T7.1mn.fit.v2 <- bnec(Suc | trials(Tot) ~ crf((x), model = "decline"),
                      data=T7.1mn.data.v2,
                      family = beta_binomial2,
                      control = list(adapt_delta = 0.99), iter = 10e3)

autoplot(T7.1mn.fit.v2, all_models = TRUE)

summary(T7.1mn.fit.v2)

rhat(T7.1mn.fit.v2, rhat_cutoff = 1.05)
#$failed none

check_chains(T7.1mn.fit.v2, filename = "Output/T7_1mn_v2_all_chains")

check_priors(T7.1mn.fit.v2, filename = "Output/T7_1mn_v2_all_priors")

T7.1mn.EC10.v2 <- ecx(T7.1mn.fit.v2, ecx_val = 10)
T7.1mn.EC10.v2^2

T7.1mn.EC50.v2 <- ecx(T7.1mn.fit.v2, ecx_val = 50)
T7.1mn.EC50.v2^2

#Plot T7.1mn.fit.amended

T7.1mn.preds.v2 <- T7.1mn.fit.v2$w_pred_vals$data
T7.1mn.pred.vals.v2 <- T7.1mn.fit.v2$w_pred_vals

pred.T7.1mn.v2 <- data.frame(up = T7.1mn.pred.vals.v2$data$Q97.5, 
                             lw = T7.1mn.pred.vals.v2$data$Q2.5, 
                             x = T7.1mn.pred.vals.v2$data$x, 
                             y = T7.1mn.pred.vals.v2$data$Estimate)

T7.1mn.p.v2 <- ggplot() +
  geom_point(data = T7.1mn.data.v2, aes(x = x, y = T7_surv, alpha = 0.10), 
             position = position_jitter(width = 1, height = 0), size = 0.75)

p4.v2 <- T7.1mn.p.v2 + 
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = T7.1mn.EC10.v2), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T7.1mn.EC50.v2), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue", 
                                "NEC" = "tomato"), name = "") +
  geom_line(data = T7.1mn.preds.v2, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T7.1mn.preds.v2, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T7.1mn.preds.v2, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "", y = "") + 
  scale_x_continuous(breaks = sqrt(c(0, 100, 400, 1000, 2000, 4000)),                                                                                      
                     labels = c("0", "100", "400", "1000", "2000", "4000")) + 
  coord_cartesian(xlim = c(-1,73), ylim=c(0,1.05)) +
  labs(title = "T7 d") + 
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T7.1mn.v2$x, ymin = pred.T7.1mn.v2$lw, ymax = pred.T7.1mn.v2$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text.y = element_text(size = 9), 
        axis.text.x = element_blank(), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8))

p4.v2
ggsave(filename = "Output/1mn_7d.png", plot = p4.v2, height = 1.4, width = 3, units = c("in"), dpi = 300)

save(T7.1mn.fit.v2, T7.1mn.EC10.v2, T7.1mn.EC50.v2, T7.1mn.preds.v2, T7.1mn.pred.vals.v2, pred.T7.1mn.v2, file = "Output/Output.T7.1mn.v2.RData")
load("Output/Output.T7.1mn.v2.RData")


## ---- T7 1MN recovery dataset -----------------------

T7rec.1mn.data.v2 <- Surv.1mn.dat.v2 %>% 
  dplyr::select(10,25) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(T7_recovery*20),
                x = sqrt(T7d_1mn), 
                Tot = 20) %>%
  as.data.frame()


T7rec.1mn.fit.v2 <- bnec(Suc | trials(Tot) ~ crf((x), model = "decline"),
                         data=T7rec.1mn.data.v2,
                         family = beta_binomial2,
                         control = list(adapt_delta = 0.99), iter = 10e3)


autoplot(T7rec.1mn.fit.v2, all_models = TRUE)

summary(T7rec.1mn.fit.v2)

rhat(T7rec.1mn.fit.v2, rhat_cutoff = 1.05)
#$failed none

check_chains(T7rec.1mn.fit.v2, filename = "Output/T7rec_1mn_v2_all_chains")

check_priors(T7rec.1mn.fit.v2, filename = "Output/T7rec_1mn_v2_all_priors")

T7rec.1mn.EC10.v2 <- ecx(T7rec.1mn.fit.v2, ecx_val = 10)
T7rec.1mn.EC10.v2^2

T7rec.1mn.EC50.v2 <- ecx(T7rec.1mn.fit.v2, ecx_val = 50)
T7rec.1mn.EC50.v2^2

#Plot T7rec.1mn.fit.new
T7rec.1mn.preds.v2 <- T7rec.1mn.fit.v2$w_pred_vals$data
T7rec.1mn.pred.vals.v2 <- T7rec.1mn.fit.v2$w_pred_vals

pred.T7rec.1mn.v2 <- data.frame(up = T7rec.1mn.pred.vals.v2$data$Q97.5, 
                                lw = T7rec.1mn.pred.vals.v2$data$Q2.5, 
                                x = T7rec.1mn.pred.vals.v2$data$x, 
                                y = T7rec.1mn.pred.vals.v2$data$Estimate)

T7rec.1mn.p.v2 <- ggplot() +
  geom_point(data = T7rec.1mn.data.v2, 
             aes(x = x, y = T7_recovery, alpha = 0.10), 
             position = position_jitter(width = 1, height = 0), size = 0.75)

p5.v2 <- T7rec.1mn.p.v2 + 
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = T7rec.1mn.EC10.v2), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T7rec.1mn.EC50.v2), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue"), name = "") +
  geom_line(data = T7rec.1mn.preds.v2, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T7rec.1mn.preds.v2, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T7rec.1mn.preds.v2, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "1-methylnaphthalene"~({mu*g~L^-1}), y = "") + 
  scale_x_continuous(breaks = sqrt(c(0, 100, 400, 1000, 2000, 4000)),                                                                                      
                     labels = c("0", "100", "400", "1000", "2000", "4000")) + 
  coord_cartesian(xlim = c(-1,73), ylim=c(0,1.05)) +
  labs(title = "+7 d Recovery") + 
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T7rec.1mn.v2$x, ymin = pred.T7rec.1mn.v2$lw, ymax = pred.T7rec.1mn.v2$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) + 
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8))

p5.v2
ggsave(filename = "Output/1mn_Rec.png", plot = p5.v2, height = 1.6, width = 3, units = c("in"), dpi = 300)

save(T7rec.1mn.fit.v2, T7rec.1mn.EC10.v2, T7rec.1mn.EC50.v2, T7rec.1mn.preds.v2, T7rec.1mn.pred.vals.v2, pred.T7rec.1mn.v2, file = "Output/Output.T7rec.1mn.v2.RData")
load("Output/Output.T7rec.1mn.v2.RData")

### --------------------------------------- ALL 1-MN Figures ------------------------------------------------
par(mfrow = c(1,6))

# Figure of T1-T4, T7 to show how ECx values change through time
# cowplot

pCombine.v2 = cowplot::plot_grid(p.v2, p1.v2, p2.v2, p3.v2, p4.v2, p5.v2, ncol=1)

pCombine.v2.test = cowplot::plot_grid(p.v2, p1.v2, p2.v2, p3.v2, p4.v2, p5.v2, ncol=1, rel_heights = c(rep(0.82/5,5), 0.17))
ggsave(filename="Output/1mn_v2_all_resize.pdf", plot=pCombine.v2.test, height = 8.35, width=3.75, units=c("in"), dpi=300)

ggsave(filename="Output/1mn_v2_all.pdf", plot=pCombine.v2, height = 8.35, width=3.75, units=c("in"), dpi=300)
ggsave(filename="Output/1mn_v2_all.png", plot=pCombine.v2, height = 10, width= 3.25, units=c("in"), dpi=300)

# Posterior probability density plot 
#pull out just ECx models since comparing EC50
MN_7d_ecx <- pull_out(T7.1mn.fit.v2, model = "ecx")
MN_7drec_ecx <- pull_out(T7rec.1mn.fit.v2, model = "ecx")

post_comp_ecx_MN <- compare_posterior(x=list("Recovery" = MN_7drec_ecx, "T7d" = MN_7d_ecx), 
                                      comparison = "ecx", ecx_val = 50)

names(post_comp_ecx_MN)
#"posterior_list" "posterior_data" "diff_list"      "diff_data"      "prob_diff"   

#Plot of posterior estimates of EC50s
post_estimates.1mn.p <- ggplot(data = post_comp_ecx_MN$posterior_data, mapping = aes(x = value)) + 
  theme_classic() +
  geom_density(mapping = aes(group = model, colour = model, fill = model), alpha = 0.3, show.legend = TRUE) +
  labs(x = "1-methylnaphthalene"~({mu*g~L^-1}), y = "") +
  scale_x_continuous(breaks = sqrt(c(0, 100, 1000, 4000)),
                     labels = c("0", "100", "1000", "4000"), limits = c(0, 68)) +
  theme(legend.position = c(0.8, 0.8)) 

post_estimates.1mn.p

post_comp_ecx_MN$prob_diff
#comparison      prob
#7dMN-RecMN 0.2745
#interpretation: There is a 27% chance that the LC50 at T7d is greater than Recovery. 

# comparison    prob
# Recovery-T7d 0.66075


###========================= NAPHTHALENE DATASET --------------------------------------------------------

Surv.naph.dat <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\Surv_data.xlsx", 
                            sheet = "naph")

##---- T1 naph dataset --------------------------------------------

T1.naph.data <- Surv.naph.dat %>% 
  dplyr::select(6,18) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(T1_surv*20),
                x = sqrt(T1d_naph), 
                Tot = as.integer(20))

T1.naph.data.use <- as.data.frame(T1.naph.data)

T1.naph.out.use2 <- bnec(Suc | trials(Tot) ~ crf((x), model = "decline"),
                         data=T1.naph.data.use,
                         family = beta_binomial2,
                         control = list(adapt_delta = 0.99), iter = 10000)

autoplot(T1.naph.out.use2, all_models = TRUE)
#Setting all 'trials' variables to 1 by default if not specified otherwise

summary(T1.naph.out.use2)
rhat(T1.naph.out.use2, rhat_cutoff=1.05) #failed nec3param

T1.naph.out.use3 <- amend(T1.naph.out.use2, drop = c("nec3param"))

T1.naph.EC10.use2 <- ecx(T1.naph.out.use3, ecx_val = 10)
T1.naph.EC10.use2^2

T1.naph.EC50.use2 <- ecx(T1.naph.out.use3, ecx_val = 50)
T1.naph.EC50.use2^2

#plot T1 naph with thresholds and CI

T1.naph.preds.use <- T1.naph.out.use3$w_pred_vals$data
T1.naph.pred.vals <- T1.naph.out.use3$w_pred_vals

pred.T1.naph <- data.frame(up = T1.naph.pred.vals$data$Q97.5, lw = T1.naph.pred.vals$data$Q2.5, 
                           x = T1.naph.pred.vals$data$x, y = T1.naph.pred.vals$data$Estimate)

T1.naph.p <- ggplot() +
  geom_point(data = T1.naph.data, aes(x = x, y = T1_surv, alpha = 0.10),
             position = position_jitter(width = 1, height = 0), size = 0.75)


p10 <- T1.naph.p + 
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = T1.naph.EC10.use2), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T1.naph.EC50.use2), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue", "NEC" = "tomato"), name = "") +
  geom_line(data = T1.naph.preds.use, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T1.naph.preds.use, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T1.naph.preds.use, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "", y = "") + 
  scale_x_continuous(breaks = sqrt(c(0, 300, 1000, 3000, 6000, 9000)), 
                     labels = c("0", "300", "1000", "3000", "6000", "9000")) + 
  coord_cartesian(xlim = c(-1,117), ylim=c(0,1.05)) + 
  labs(title = "T1 d") +
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T1.naph$x, ymin = pred.T1.naph$lw, ymax = pred.T1.naph$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8))   

p10
ggsave(filename="naph_T1.pdf", plot=p10, height = 4, width=3.5, units=c("in"), dpi=300)

save(T1.naph.out.use2, T1.naph.out.use3, T1.naph.EC10.use2, T1.naph.EC50.use2, T1.naph.NEC.use2, file = "Output.T1.naph.use2.RData")
load("Output.T1.naph.use2.RData")

##------------------T2 naphthalene dataset -----------------------------------------------------------

T2.naph.data <- Surv.naph.dat %>% 
  dplyr::select(7,19) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(T2_surv*20),
                x = sqrt(T2d_naph), 
                Tot = as.integer(20))

T2.naph.data.use <- as.data.frame(T2.naph.data)

T2.naph.out.use <- bnec(Suc | trials(Tot) ~ crf((x), model = "decline"),
                        data=T2.naph.data.use,
                        family = beta_binomial2,
                        control = list(adapt_delta = 0.99), iter = 10e3)

autoplot(T2.naph.out.use, all_models = TRUE)
summary(T2.naph.out.use)

rhat(T2.naph.out.use, rhat_cutoff=1.05)
#$ no models failed

check_chains(T2.naph.out.use, filename = "T2_naph_use_all_chains")
check_priors(T2.naph.out.use$mod_fits$ecxwb1)
check_priors(T2.naph.out.use, filename = "T2_naph_use_all_priors")

T2.naph.EC10.use <- ecx(T2.naph.out.use, ecx_val = 10)
T2.naph.EC10.use^2

T2.naph.EC50.use <- ecx(T2.naph.out.use, ecx_val = 50)
T2.naph.EC50.use^2

#Plot T2 naphthalene.out.use

T2.naph.preds.use <- T2.naph.out.use$w_pred_vals$data
T2.naph.pred.vals <- T2.naph.out.use$w_pred_vals

pred.T2.naph <- data.frame(up = T2.naph.pred.vals$data$Q97.5, lw = T2.naph.pred.vals$data$Q2.5, x = T2.naph.pred.vals$data$x, y = T2.naph.pred.vals$data$Estimate)

T2.naph.p.use <- ggplot() +
  geom_point(data = T2.naph.data, aes(x = x, y = T2_surv, alpha = 0.10), 
             position = position_jitter(width = 1, height = 0), size = 0.75)

p11 <- T2.naph.p.use + 
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = T2.naph.EC10.use), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T2.naph.EC50.use), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue", "NEC" = "tomato"), name = "") +
  geom_line(data = T2.naph.preds.use, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T2.naph.preds.use, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T2.naph.preds.use, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "", y = "") + 
  scale_x_continuous(breaks = sqrt(c(0, 300, 1000, 3000, 6000, 9000)), 
                     labels = c("0", "300", "1000", "3000", "6000", "9000")) + 
  coord_cartesian(xlim = c(-1,117), ylim=c(0,1.05)) + 
  labs(title = "T2 d") +
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T2.naph$x, ymin = pred.T2.naph$lw, ymax = pred.T2.naph$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8))  

p11
ggsave(filename="naph_T2.pdf", plot=p11, height = 4, width=3.5, units=c("in"), dpi=300)

save(T2.naph.out.use, T2.naph.NEC.use, T2.naph.EC10.use, T2.naph.EC50.use, file = "Output.T2.naph.use.RData")
load("Output.T2.naph.use.RData")

##------- T3 naphthalene dataset ----------------------------------------------------------------------

T3.naph.data <- Surv.naph.dat %>% 
  dplyr::select(8,20) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(T3_surv*20),
                x = sqrt(T3d_naph), 
                Tot = as.integer(20))

T3.naph.data.use <- as.data.frame(T3.naph.data)

T3.naph.out.use <- bnec(Suc | trials(Tot) ~ crf((x), model = "decline"),
                        data=T3.naph.data.use,
                        family = beta_binomial2,
                        control = list(adapt_delta = 0.99), iter = 10e3)


autoplot(T3.naph.out.use, all_models = TRUE)
summary(T3.naph.out.use)

check_chains(T3.naph.out.use, filename = "T3_naph_use_all_chains")
check_priors(T3.naph.out.use$mod_fits$nec3param)
check_priors(T3.naph.out.use, filename = "T3_naph_use_all_priors")

rhat(T3.naph.out.use, rhat_cutoff = 1.05)
#no models failed

T3.naph.EC10.use <- ecx(T3.naph.out.use, ecx_val = 10)
T3.naph.EC10.use^2

T3.naph.EC50.use <- ecx(T3.naph.out.use, ecx_val = 50)
T3.naph.EC50.use^2

#Plot T3 naphthalene

T3.naph.preds.use <- T3.naph.out.use$w_pred_vals$data
T3.naph.pred.vals <- T3.naph.out.use$w_pred_vals

pred.T3.naph <- data.frame(up = T3.naph.pred.vals$data$Q97.5, lw = T3.naph.pred.vals$data$Q2.5, x = T3.naph.pred.vals$data$x, y = T3.naph.pred.vals$data$Estimate)

T3.naph.p.use <- ggplot() +
  geom_point(data = T3.naph.data, aes(x = x, y = T3_surv, alpha = 0.10), 
             position = position_jitter(width = 1, height = 0), size = 0.75)

p12 <- T3.naph.p.use + 
  geom_vline(mapping = aes(xintercept = T3.naph.EC10.use), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T3.naph.EC50.use), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue", "NEC" = "tomato"), name = "") +
  geom_line(data = T3.naph.preds.use, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T3.naph.preds.use, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T3.naph.preds.use, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "", y = "") + 
  scale_x_continuous(breaks = sqrt(c(0, 300, 1000, 3000, 6000, 9000)), 
                     labels = c("0", "300", "1000", "3000", "6000", "9000")) + 
  coord_cartesian(xlim = c(-1,117), ylim=c(0,1.05)) + 
  labs(title = "T3 d") +
  theme_classic() + 
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T3.naph$x, ymin = pred.T3.naph$lw, ymax = pred.T3.naph$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8))  

p12
ggsave(filename="naph_T3.pdf", plot=p12, height = 4, width=3.5, units=c("in"), dpi=300)

save(T3.naph.out.use, T3.naph.NEC.use, T3.naph.EC10.use, T3.naph.EC50.use, file = "Output.T3.naph.use.RData")
load("Output.T3.naph.use.RData")

## ---------- T4 naphthalene dataset --------------------------------------------------------------------------------

Surv.naph.dat <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\Surv_data.xlsx", 
                            sheet = "naph")

T4.naph.data <- Surv.naph.dat %>% 
  dplyr::select(9,21) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(T4_surv*20),
                x = sqrt(T4d_naph), 
                Tot = as.integer(20))


T4.naph.out.use <- bnec(Suc | trials(Tot) ~ crf((x), model = "decline"),
                        data=T4.naph.data,
                        family = beta_binomial2,
                        control = list(adapt_delta = 0.99), iter = 10e3)


autoplot(T4.naph.out.use, all_models = TRUE)
summary(T4.naph.out.use)

check_chains(T4.naph.out.use, filename = "T4_naph_use_all_chains")
check_priors(T4.naph.out.use$mod_fits$nec3param)
check_priors(T4.naph.out.use, filename = "T4_naph_use_all_priors")

rhat(T4.naph.out.use, rhat_cutoff = 1.05)
#no models failed

T4.naph.EC10.use <- ecx(T4.naph.out.use, ecx_val = 10)
T4.naph.EC10.use^2

T4.naph.EC50.use <- ecx(T4.naph.out.use, ecx_val = 50)
T4.naph.EC50.use^2

#Plot T4 naphthalene

T4.naph.preds.use <- T4.naph.out.use$w_pred_vals$data
T4.naph.pred.vals <- T4.naph.out.use$w_pred_vals

pred.T4.naph <- data.frame(up = T4.naph.pred.vals$data$Q97.5, lw = T4.naph.pred.vals$data$Q2.5, x = T4.naph.pred.vals$data$x, y = T4.naph.pred.vals$data$Estimate)

T4.naph.p.use <- ggplot() +
  geom_point(data = T4.naph.data, aes(x = x, y = T4_surv, alpha = 0.10), 
             position = position_jitter(width = 1, height = 0), size = 0.75)

p13 <- T4.naph.p.use + 
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = T4.naph.EC10.use), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T4.naph.EC50.use), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue", "NEC" = "tomato"), name = "") +
  geom_line(data = T4.naph.preds.use, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T4.naph.preds.use, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T4.naph.preds.use, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "", y = "Proportion of survivorship") + 
  scale_x_continuous(breaks = sqrt(c(0, 300, 1000, 3000, 6000, 9000)), 
                     labels = c("0", "300", "1000", "3000", "6000", "9000")) + 
  coord_cartesian(xlim = c(-1,117), ylim=c(0,1.05)) + 
  labs(title = "T4 d") +
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T4.naph$x, ymin = pred.T4.naph$lw, ymax = pred.T4.naph$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 8),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8))  

p13
ggsave(filename="naph_T4.pdf", plot=p13, height = 4, width=3.5, units=c("in"), dpi=300)

save(T4.naph.out.use, T4.naph.NEC.use, T4.naph.EC10.use, T4.naph.EC50.use, file = "Output.T4.naph.use.RData")
load("Output.T4.naph.use.RData")

## --------- T7 naphthalene dataset   --------------------------------------------------------------------------

T7.naph.data <- Surv.naph.dat %>% 
  dplyr::select(10,24) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(T7_surv*20),
                x = sqrt(T7d_naph), 
                Tot = as.integer(20))

T7.naph.data.use <- as.data.frame(T7.naph.data)

T7.naph.out.use <- bnec(Suc | trials(Tot) ~ crf((x), model = "decline"),
                        data=T7.naph.data.use,
                        family = beta_binomial2,
                        control = list(adapt_delta = 0.99), iter = 10e3)


autoplot(T7.naph.out.use, all_models = TRUE)
summary(T7.naph.out.use)

rhat(T7.naph.out.use, rhat_cutoff=1.05)
#$failed "nec3param" "nec4param" "necsigm"

check_chains(T7.naph.out.use, filename = "T7_naph_use_all_chains")
check_priors(T7.naph.out.use$mod_fits$ecxwb1)
check_priors(T7.naph.out.use, filename = "T7_naph_use_all_priors")

T7.naph.out.use2 <- amend(T7.naph.out.use, drop = c("nec3param", "nec4param", "necsigm"))

T7.naph.EC10.use <- ecx(T7.naph.out.use2, ecx_val = 10)
T7.naph.EC10.use^2

T7.naph.EC50.use <- ecx(T7.naph.out.use2, ecx_val = 50)
T7.naph.EC50.use^2

#Plot T7 naphthalene

T7.naph.preds.use <- T7.naph.out.use2$w_pred_vals$data
T7.naph.pred.vals <- T7.naph.out.use2$w_pred_vals

pred.T7.naph <- data.frame(up = T7.naph.pred.vals$data$Q97.5, lw = T7.naph.pred.vals$data$Q2.5, x = T7.naph.pred.vals$data$x, y = T7.naph.pred.vals$data$Estimate)

T7.naph.p.use <- ggplot() +
  geom_point(data = T7.naph.data, aes(x = x, y = T7_surv, alpha = 0.10), 
             position = position_jitter(width = 1, height = 0), size = 0.75)

p14 <- T7.naph.p.use + 
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = T7.naph.EC10.use), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T7.naph.EC50.use), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue", "NEC" = "tomato"), name = "") +
  geom_line(data = T7.naph.preds.use, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T7.naph.preds.use, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T7.naph.preds.use, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "", y = "") + 
  scale_x_continuous(breaks = sqrt(c(0, 300, 1000, 3000, 6000, 9000)), 
                     labels = c("0", "300", "1000", "3000", "6000", "9000")) + 
  coord_cartesian(xlim = c(-1,117), ylim=c(0,1.05)) + 
  labs(title = "T7 d") +
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T7.naph$x, ymin = pred.T7.naph$lw, ymax = pred.T7.naph$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8))  

p14
ggsave(filename="naph_T7.pdf", plot=p14, height = 4, width=3.5, units=c("in"), dpi=300)

save(T7.naph.out.use, T7.naph.out.use2, T7.naph.EC10.use, T7.naph.EC50.use, file = "Output.T7.naph.use.RData")
load("Output.T7.naph.use.RData")

# --- T7 recovery naph -------------------------------------------------------
T7rec.naph.data <- Surv.naph.dat %>% 
  dplyr::select(10,25) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(T7_recovery*20),
                x = sqrt(T7d_naph), 
                Tot = as.integer(20)) %>%
  data.frame()

T7rec.naph.out.use <- bnec(Suc | trials(Tot) ~ crf((x), model = "decline"),
                           data=T7rec.naph.data,
                           family = beta_binomial2,
                           control = list(adapt_delta = 0.99), iter = 10e3)

autoplot(T7rec.naph.out.use, all_models = TRUE)

summary(T7rec.naph.out.use)

rhat(T7rec.naph.out.use, rhat_cutoff=1.05)
#nec4param failed

check_chains(T7rec.naph.out.use, filename = "T7rec_naph_use_all_chains")
check_priors(T7rec.naph.out.use$mod_fits$ecxwb1)
check_priors(T7rec.naph.out.use, filename = "T7rec_naph_use_all_priors")

T7rec.naph.out.use2 <- amend(T7rec.naph.out.use, drop = c("nec4param"))

T7rec.naph.EC10.use <- ecx(T7rec.naph.out.use2, ecx_val = 10)
T7rec.naph.EC10.use^2

T7rec.naph.EC50.use <- ecx(T7rec.naph.out.use2, ecx_val = 50)
T7rec.naph.EC50.use^2

#Plot T7 recovery naphthalene

T7rec.naph.preds.use <- T7rec.naph.out.use2$w_pred_vals$data
T7rec.naph.pred.vals <- T7rec.naph.out.use2$w_pred_vals

pred.T7rec.naph <- data.frame(up = T7rec.naph.pred.vals$data$Q97.5, lw = T7rec.naph.pred.vals$data$Q2.5, x = T7rec.naph.pred.vals$data$x, y = T7rec.naph.pred.vals$data$Estimate)

T7rec.naph.p.use <- ggplot() +
  geom_point(data = T7rec.naph.data, aes(x = x, y = T7_recovery, alpha = 0.10), 
             position = position_jitter(width = 1, height = 0), size = 0.75)

p15 <- T7rec.naph.p.use + 
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = T7rec.naph.EC10.use), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T7rec.naph.EC50.use), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue", "NEC" = "tomato"), name = "") +
  geom_line(data = T7rec.naph.preds.use, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T7rec.naph.preds.use, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T7rec.naph.preds.use, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "Naphthalene"~({mu*g~L^-1}), y = "") + 
  scale_x_continuous(breaks = sqrt(c(0, 300, 1000, 3000, 6000, 9000)), 
                     labels = c("0", "300", "1000", "3000", "6000", "9000")) + 
  coord_cartesian(xlim = c(-1,117), ylim=c(0,1.05)) + 
  labs(title = "+7 d Recovery") +
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T7rec.naph$x, ymin = pred.T7rec.naph$lw, ymax = pred.T7rec.naph$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8))  

p15
ggsave(filename="naph_T7rec.pdf", plot=p15, height = 4, width=3.5, units=c("in"), dpi=300)

save(T7rec.naph.out.use, T7rec.naph.out.use2, T7rec.naph.NEC.use, T7rec.naph.EC10.use, T7rec.naph.EC50.use, file = "Output.T7rec.naph.use.RData")
load("Output.T7rec.naph.use.RData")

#----- ALL Naph Figures ----------------------------------------------------------------

# combine naph plot
pCombine2 = cowplot::plot_grid(p10, p11, p12, p13, p14, p15, ncol=1)
ggsave(filename="naph_all.pdf", plot=pCombine2, height = 8.5, width = 4.5, units=c("in"), dpi=300)
ggsave(filename="naph_all.png", plot=pCombine2, height = 8.35, width = 3.75, units=c("in"), dpi=300)

pCombine2.v2 = cowplot::plot_grid(p10, p11, p12, p13, p14, p15, ncol=1, rel_heights = c(rep(0.82/5,5), 0.17))
ggsave(filename="Output/Naph_all_resize.pdf", plot=pCombine2.v2, height = 8.35, width=3.75, units=c("in"), dpi=300)


# ======= TOLUENE DATASET ==========================================================================================


Surv.tol.dat <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\Surv_data.xlsx", 
                           sheet = "tol")

# --------- T1 toluene dataset ----------------------------------------------------------------------
#using family bernoulli distribution as lots of 0's and 1's; bernoulli is a special cae of binomial distribution where a single trial is conducted

T1.tol.data <- Surv.tol.dat %>% 
  dplyr::select(6,11,18) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(ifelse(T1_mort <= 0.05, 1, T1_surv)),
                x = sqrt(T1d_tol))%>%
  data.frame()

T1.tol.out.use <- bnec(Suc ~ crf((x), model = "decline"),
                       data = T1.tol.data,
                       family = bernoulli(link = "identity"), 
                       iter = 10e3, control = list(adapt_delta = 0.99))


autoplot(T1.tol.out.use, all_models = TRUE)
summary(T1.tol.out.use)

rhat(T1.tol.out.use, rhat_cutoff = 1.05)
# no models failed

T1.tol.EC10.use <- ecx(T1.tol.out.use, ecx_val = 10)
T1.tol.EC10.use^2

T1.tol.EC50.use <- ecx(T1.tol.out.use, ecx_val = 50)
T1.tol.EC50.use^2

#Plot T1 toluene using bernoulli distribution

T1.tol.preds.use <- T1.tol.out.use$w_pred_vals$data
T1.tol.pred.vals <- T1.tol.out.use$w_pred_vals

pred.T1.tol <- data.frame(up = T1.tol.pred.vals$data$Q97.5, lw = T1.tol.pred.vals$data$Q2.5, x = T1.tol.pred.vals$data$x, y = T1.tol.pred.vals$data$Estimate)

T1.tol.p.use <- ggplot() +
  geom_point(data = T1.tol.data, aes(x = x, y = T1_surv, alpha = 0.1),
             position = position_jitter(width = 1, height = 0), size = 0.75)

p20 <- T1.tol.p.use + 
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = T1.tol.EC10.use), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T1.tol.EC50.use), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue", "NEC" = "tomato"), name = "") +
  geom_line(data = T1.tol.preds.use, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T1.tol.preds.use, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T1.tol.preds.use, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "", y = "") + 
  scale_x_continuous(breaks = sqrt(c(0, 1000, 10000, 30000, 60000, 120000)), 
                     labels = c("0", "1000", "10000", "30000", "60000", "120000")) +
  coord_cartesian(xlim = c(-1,357), ylim=c(0,1.05)) +   
  labs(title = "T1 d") +
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T1.tol$x, ymin = pred.T1.tol$lw, ymax = pred.T1.tol$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8)) 
p20
ggsave(filename="tol_T1.pdf", plot=p20, height = 4, width=3.5, units=c("in"), dpi=300)

save(T1.tol.out.use, T1.tol.NEC.use, T1.tol.EC10.use, T1.tol.EC50.use, file = "Output.T1.tol.use.RData")
load("Output.T1.tol.use.RData")

# ------------- T2 toluene dataset --------------------------------------------------------------------------
#using family bernoulli distribution as lots of 0's and 1's

T2.tol.data <- Surv.tol.dat %>% 
  dplyr::select(7,12,19) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(ifelse(T2_mort <= 0.05, 1, T2_surv)),
                x = sqrt(T2d_tol))

T2.tol.data.use <- as.data.frame(T2.tol.data)

T2.tol.out.use <- bnec(Suc ~ crf((x), model = "decline"),
                       data = T2.tol.data.use,
                       family = bernoulli(link = "identity"), 
                       iter = 10e3, control = list(adapt_delta = 0.99))

autoplot(T2.tol.out.use, all_models = TRUE)
summary(T2.tol.out.use)

rhat(T2.tol.out.use, rhat_cutoff = 1.05)
# no models failed

check_chains(T2.tol.out.use, filename = "T2_tol_use_all_chains")
check_priors(T2.tol.out.use$mod_fits$ecxll3)
check_priors(T2.tol.out.use, filename = "T2_tol_use_all_priors")

T2.tol.EC10.use <- ecx(T2.tol.out.use, ecx_val = 10)
T2.tol.EC10.use^2

T2.tol.EC50.use <- ecx(T2.tol.out.use, ecx_val = 50)
T2.tol.EC50.use^2

#Plot T2 toluene

T2.tol.preds.use <- T2.tol.out.use$w_pred_vals$data
T2.tol.pred.vals <- T2.tol.out.use$w_pred_vals

pred.T2.tol <- data.frame(up = T2.tol.pred.vals$data$Q97.5, lw = T2.tol.pred.vals$data$Q2.5, x = T2.tol.pred.vals$data$x, y = T2.tol.pred.vals$data$Estimate)

T2.tol.p.use <- ggplot() +
  geom_point(data = T2.tol.data, aes(x = x, y = T2_surv, alpha = 0.10), 
             position = position_jitter(width = 1, height = 0), size = 0.75)

p21 <- T2.tol.p.use +   
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = T2.tol.EC10.use), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T2.tol.EC50.use), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue", "NEC" = "tomato"), name = "") +
  geom_line(data = T2.tol.preds.use, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T2.tol.preds.use, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T2.tol.preds.use, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "", y = "") + 
  scale_x_continuous(breaks = sqrt(c(0, 1000, 10000, 30000, 60000, 120000)), 
                     labels = c("0", "1000", "10000", "30000", "60000", "120000")) +
  coord_cartesian(xlim = c(-1,357), ylim=c(0,1.05)) +  
  labs(title = "T2 d") +
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T2.tol$x, ymin = pred.T2.tol$lw, ymax = pred.T2.tol$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8))  
p21
ggsave(filename="tol_T2.pdf", plot=p21, height = 4, width=3.5, units=c("in"), dpi=300)

save(T2.tol.out.use, T2.tol.NEC, T2.tol.EC10.use, T2.tol.EC50.use, file = "Output.T2.tol.use.RData")
load("Output.T2.tol.use.RData")
# ---------- T3 toluene dataset using bernoulli distribution --------------------------------------------

Surv.tol.dat <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\Surv_data.xlsx", 
                           sheet = "tol")
T3.tol.data <- Surv.tol.dat %>% 
  dplyr::select(8,13,20) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(ifelse(T3_mort <= 0.05, 1, T3_surv)),
                x = sqrt(T3d_tol)) %>%
  data.frame()


T3.tol.out.use <- bnec(Suc ~ crf((x), model = "decline"),
                       data = T3.tol.data,
                       family = bernoulli(link = "identity"), 
                       iter = 10e3, control = list(adapt_delta = 0.99))

autoplot(T3.tol.out.use, all_models = TRUE)
summary(T3.tol.out.use)

rhat(T3.tol.out.use, rhat_cutoff = 1.05)
# no models failed

check_chains(T3.tol.out.use, filename = "T3_tol_use_all_chains")
check_priors(T3.tol.out.use$mod_fits$ecxll3)
check_priors(T3.tol.out.use, filename = "T3_tol_use_all_priors")

T3.tol.EC10.use <- ecx(T3.tol.out.use, ecx_val = 10)
T3.tol.EC10.use^2

T3.tol.EC50.use <- ecx(T3.tol.out.use, ecx_val = 50)
T3.tol.EC50.use^2

#Plot T3 toluene using bernoulli distribution

T3.tol.preds.use <- T3.tol.out.use$w_pred_vals$data
T3.tol.pred.vals <- T3.tol.out.use$w_pred_vals

pred.T3.tol <- data.frame(up = T3.tol.pred.vals$data$Q97.5, lw = T3.tol.pred.vals$data$Q2.5, x = T3.tol.pred.vals$data$x, y = T3.tol.pred.vals$data$Estimate)

T3.tol.p.use <- ggplot() +
  geom_point(data = T3.tol.data, aes(x = x, y = T3_surv, alpha = 0.10), 
             position = position_jitter(width = 1, height = 0), size = 0.75)

p22 <- T3.tol.p.use +  
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = T3.tol.EC10.use), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T3.tol.EC50.use), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue", "NEC" = "tomato"), name = "") +
  geom_line(data = T3.tol.preds.use, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T3.tol.preds.use, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T3.tol.preds.use, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "", y = "") + 
  scale_x_continuous(breaks = sqrt(c(0, 1000, 10000, 30000, 60000, 120000)), 
                     labels = c("0", "1000", "10000", "30000", "60000", "120000")) +
  labs(title = "T3 d") +
  theme(legend.position = "none") +
  coord_cartesian(xlim = c(-1,357), ylim=c(0,1.05)) + 
  geom_ribbon(aes(x = pred.T3.tol$x, ymin = pred.T3.tol$lw, ymax = pred.T3.tol$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8))  
p22
ggsave(filename="tol_T3.pdf", plot=p22, height = 4, width=3.5, units=c("in"), dpi=300)

save(T3.tol.out.use, T3.tol.NEC.use, T3.tol.EC10.use, T3.tol.EC50.use, file = "Output.T3.tol.use.RData")
load("Output.T3.tol.use.RData")

# ----------- T4 toluene dataset using bernoulli distribution -----------------

Surv.tol.dat <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\Surv_data.xlsx", 
                           sheet = "tol")

T4.tol.data <- Surv.tol.dat %>% 
  dplyr::select(9,14,21) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(ifelse(T4_mort <= 0.05, 1, T4_surv)),
                x = sqrt(T4d_tol)) %>%
  data.frame()

T4.tol.out.use <- bnec(Suc ~ crf((x), model = "decline"),
                       data = T4.tol.data,
                       family = bernoulli(link = "identity"), 
                       iter = 10e3, control = list(adapt_delta = 0.99))

autoplot(T4.tol.out.use, all_models = TRUE)
summary(T4.tol.out.use)

rhat(T4.tol.out.use, rhat_cutoff = 1.05)
# no models failed

check_chains(T4.tol.out.use, filename = "T4_tol_use_all_chains")
check_priors(T4.tol.out.use$mod_fits$nec3param)
check_priors(T4.tol.out.use, filename = "T4_tol_use_all_priors")

T4.tol.EC10.use <- ecx(T4.tol.out.use, ecx_val = 10)
T4.tol.EC10.use^2

T4.tol.EC50.use <- ecx(T4.tol.out.use, ecx_val = 50)
T4.tol.EC50.use^2

#Plot T4 toluene using bernoulli distribution

T4.tol.preds.use <- T4.tol.out.use$w_pred_vals$data
T4.tol.pred.vals <- T4.tol.out.use$w_pred_vals

pred.T4.tol <- data.frame(up = T4.tol.pred.vals$data$Q97.5, lw = T4.tol.pred.vals$data$Q2.5, x = T4.tol.pred.vals$data$x, y = T4.tol.pred.vals$data$Estimate)

T4.tol.p.use <- ggplot() +
  geom_point(data = T4.tol.data, aes(x = x, y = T4_surv, alpha = 0.10),
             position = position_jitter(width = 1, height = 0), size = 0.75)

p23 <- T4.tol.p.use + 
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = T4.tol.EC10.use), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T4.tol.EC50.use), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue", "NEC" = "tomato"), name = "") +
  geom_line(data = T4.tol.preds.use, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T4.tol.preds.use, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T4.tol.preds.use, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "", y = "Proportion of survivorship") + 
  scale_x_continuous(breaks = sqrt(c(0, 1000, 10000, 30000, 60000, 120000)), 
                     labels = c("0", "1000", "10000", "30000", "60000", "120000")) +
  labs(title = "T4 d") +
  theme(legend.position = "none") +
  coord_cartesian(xlim = c(-1,357), ylim=c(0,1.05)) + 
  geom_ribbon(aes(x = pred.T4.tol$x, ymin = pred.T4.tol$lw, ymax = pred.T4.tol$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 8),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8))  

p23
ggsave(filename="tol_T4.pdf", plot=p23, height = 4, width=3.5, units=c("in"), dpi=300)

save(T4.tol.out.use, T4.tol.NEC.use, T4.tol.EC10.use, T4.tol.EC50.use, file = "Output.T4.tol.use.RData")
load("Output.T4.tol.use.RData")

#---T7 toluene dataset----------------

Surv.tol.dat <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\Surv_data.xlsx", 
                           sheet = "tol")

T7.tol.data <- Surv.tol.dat %>%
  dplyr::select(10,24) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(T7_surv*20),
                x = sqrt(T7d_tol),
                Tot = as.integer(20)) %>%
  data.frame()

T7.tol.out.use <- bnec(Suc | trials(Tot) ~ crf((x), model = "decline"),
                       data=T7.tol.data,
                       family = beta_binomial2,
                       control = list(adapt_delta = 0.99), iter = 10e3)

autoplot(T7.tol.out.use, all_models = TRUE)
summary(T7.tol.out.use)

check_chains(T7.tol.out.use, filename = "T7_tol_use_all_chains")
check_priors(T7.tol.out.use$mod_fits$ecx4param)
check_priors(T7.tol.out.use, filename = "T7_tol_use_all_priors")

rhat(T7.tol.out.use, rhat_cutoff = 1.05)
#no models failed

T7.tol.EC10.use <- ecx(T7.tol.out.use, ecx_val = 10)
T7.tol.EC10.use^2

T7.tol.EC50.use <- ecx(T7.tol.out.use, ecx_val = 50)
T7.tol.EC50.use^2

#Plot T7 toluene out.use

T7.tol.preds.use <- T7.tol.out.use$w_pred_vals$data
T7.tol.pred.vals <- T7.tol.out.use$w_pred_vals

pred.T7.tol <- data.frame(up = T7.tol.pred.vals$data$Q97.5, lw = T7.tol.pred.vals$data$Q2.5, x = T7.tol.pred.vals$data$x, y = T7.tol.pred.vals$data$Estimate)

T7.tol.p.use <- ggplot() +
  geom_point(data = T7.tol.data, aes(x = x, y = T7_surv, alpha = 0.10),
             position = position_jitter(width = 1, height = 0), size = 0.75)

p24 <- T7.tol.p.use + 
  theme_classic() +
  geom_vline(mapping = aes(xintercept = T7.tol.EC10.use), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T7.tol.EC50.use), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue", "NEC" = "tomato"), name = "") +
  geom_line(data = T7.tol.preds.use, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T7.tol.preds.use, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T7.tol.preds.use, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "", y = "") + 
  scale_x_continuous(breaks = sqrt(c(0, 1000, 10000, 30000, 60000, 120000)), 
                     labels = c("0", "1000", "10000", "30000", "60000", "120000")) +
  labs(title = "T7 d") +
  coord_cartesian(xlim = c(-1,357), ylim=c(0,1.05)) + 
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T7.tol$x, ymin = pred.T7.tol$lw, ymax = pred.T7.tol$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),plot.title = element_text(size = 8)) 

p24
ggsave(filename="tol_T7.pdf", plot=p24, height = 4, width=3.5, units=c("in"), dpi=300)

save(T7.tol.out.use, T7.tol.NEC.use, T7.tol.EC10.use, T7.tol.EC50.use, file = "Output.T7.tol.use.RData")
load("Output.T7.tol.use.RData")

# --- T7 recovery toluene --------------
T7rec.tol.data <- Surv.tol.dat %>% 
  dplyr::select(10,25) %>%
  na.omit() %>%
  dplyr::mutate(Suc = as.integer(T7_recovery*20),
                x = sqrt(T7d_tol), 
                Tot = as.integer(20)) %>%
  data.frame()

T7rec.tol.out.use <- bnec(Suc | trials(Tot) ~ crf((x), model = "decline"),
                          data=T7rec.tol.data,
                          family = beta_binomial2,
                          control = list(adapt_delta = 0.99), iter = 10e3)

autoplot(T7rec.tol.out.use, all_models = TRUE)
summary(T7rec.tol.out.use)

check_chains(T7rec.tol.out.use, filename = "T7rec_tol_use_all_chains")
check_priors(T7rec.tol.out.use$mod_fits$ecxwb1) #best model fit
check_priors(T7rec.tol.out.use, filename = "T7rec_tol_use_all_priors")

rhat(T7rec.tol.out.use, rhat_cutoff = 1.05)
#no models failed

T7rec.tol.EC10.use <- ecx(T7rec.tol.out.use, ecx_val = 10)
T7rec.tol.EC10.use^2

T7rec.tol.EC50.use <- ecx(T7rec.tol.out.use, ecx_val = 50)
T7rec.tol.EC50.use^2

#Plot T7 recovery toluene out.use

T7rec.tol.preds.use <- T7rec.tol.out.use$w_pred_vals$data
T7rec.tol.pred.vals <- T7rec.tol.out.use$w_pred_vals

pred.T7rec.tol <- data.frame(up = T7rec.tol.pred.vals$data$Q97.5, lw = T7rec.tol.pred.vals$data$Q2.5, x = T7rec.tol.pred.vals$data$x, y = T7rec.tol.pred.vals$data$Estimate)

T7rec.tol.p.use <- ggplot() +
  geom_point(data = T7rec.tol.data, aes(x = x, y = T7_recovery, alpha = 0.10), 
             position = position_jitter(width = 1, height = 0), size = 0.75)

p25 <- T7rec.tol.p.use + 
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = T7rec.tol.EC10.use), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = T7rec.tol.EC50.use), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue", "NEC" = "tomato"), name = "") +
  geom_line(data = T7rec.tol.preds.use, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = T7rec.tol.preds.use, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = T7rec.tol.preds.use, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "Toluene"~({mu*g~L^-1}), y = "") + 
  scale_x_continuous(breaks = sqrt(c(0, 1000, 10000, 30000, 60000, 120000)), 
                     labels = c("0", "1000", "10000", "30000", "60000", "120000")) +
  coord_cartesian(xlim = c(-1,357), ylim=c(0,1.05)) + 
  labs(title = "+7 d Recovery") +
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.T7rec.tol$x, ymin = pred.T7rec.tol$lw, ymax = pred.T7rec.tol$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 8)) 

p25
ggsave(filename="tol_T7rec.pdf", plot=p25, height = 4, width=3.5, units=c("in"), dpi=300)

save(T7rec.tol.out.use, T7rec.tol.NEC.use, T7rec.tol.EC10.use, T7rec.tol.EC50.use, file = "Output.T7rec.tol.use.RData")
load("Output.T7rec.tol.use.RData")

#----ALL Toluene Figures---------------------------
# combine toluene plots
pCombine3 = cowplot::plot_grid(p20, p21, p22, p23, p24, p25, ncol=1)
ggsave(filename="tol_all.pdf", plot=pCombine3, height = 8.25, width = 3.75, units=c("in"), dpi=300)
ggsave(filename="tol_all.png", plot=pCombine3, height = 8.25, width = 3.75, units=c("in"), dpi=300)

#resized
pCombine3.v2 = cowplot::plot_grid(p20, p21, p22, p23, p24, p25, ncol=1, rel_heights = c(rep(0.82/5,5), 0.17))
ggsave(filename="Output/Tol_all_resize.pdf", plot=pCombine3.v2, height = 8.35, width=3.75, units=c("in"), dpi=300)

#------------Comparisons: T7d and Recovery curves ----------------------------------------------------------
#Toluene comparison -----

load("Output.T7.tol.use.RData")
load("Output.T7rec.tol.use.RData")

tol_7d_ecx <- pull_out(T7.tol.out.use, model = "ecx")
tol_7drec_ecx <- pull_out(T7rec.tol.out.use, model = "ecx")

post_comp_ecx_tol2 <- compare_posterior(x=list("7dTol" = tol_7d_ecx, "RecTol" = tol_7drec_ecx), 
                                        comparison = "ecx", ecx_val = 50)

post_estimates.tol.p <- ggplot(data = post_comp_ecx_tol2$posterior_data, mapping = aes(x = value)) + 
  geom_density(mapping = aes(group = model, colour = model, fill = model), show.legend = NA, alpha = 0.3) +
  scale_x_continuous(breaks = sqrt(c(0, 3000, 30000, 90000)),
                     labels = c("0", "3000", "30000", "90000"), limits = c(0, 303)) +
  labs(x = "Toluene"~({mu*g~L^-1}), y = "Density") + 
  theme_classic() + theme(legend.position = "none")
post_estimates.tol.p

post_comp_ecx_tol2$prob_diff
# comparison     prob
# 1 7dTol-RecTol 0.221375
#There is a 22% chance that LC50 at 7d is greater than LC50 at recovery

#Naphthalene comparisons-------------------------------------------------------------------------

load("Output.T7.naph.use.RData")
load("Output.T7rec.naph.use.RData")

naph_7d_ecx <- pull_out(T7.naph.out.use2, model = "ecx")
naph_7drec_ecx <- pull_out(T7rec.naph.out.use2, model = "ecx")

post_comp_ecx_naph2 <- compare_posterior(x=list("7dNaph" = naph_7d_ecx,"RecNaph" = naph_7drec_ecx), 
                                         comparison = "ecx", ecx_val = 50)

post_estimates.naph.p <- ggplot(data = post_comp_ecx_naph2$posterior_data, mapping = aes(x = value)) + 
  geom_density(mapping = aes(group = model, colour = model, fill = model), show.legend = NA, alpha = 0.3) +
  scale_x_continuous(breaks = sqrt(c(0, 300, 3000, 9000)),
                     labels = c("0", "300", "3000", "9000"), limits = c(0, 107)) +
  labs(x = "Naphthalene"~({mu*g~L^-1}), y = "") + 
  theme_classic() + 
  theme(legend.position = "none")
post_estimates.naph.p

post_comp_ecx_naph2$prob_diff
# omparison  prob
#1 7dNaph-RecNaph 0.007
#There is a 0.7% chance that 7d naphthalene is greater than the LC50 at Recovery

# 1-MN comparisons -----------------------------

load("Output/Output.T7.1mn.v2.RData")
load("Output/Output.T7rec.1mn.v2.RData")


#pull out just ECx models since comparing EC50
MN_7d_ecx <- pull_out(T7.1mn.output, model = "ecx")
MN_7drec_ecx <- pull_out(T7rec.1mn.out.use, model = "ecx")

post_comp_ecx_MN <- compare_posterior(x=list("T7d" = MN_7d_ecx, "Recovery" = MN_7drec_ecx), 
                                      comparison = "ecx", ecx_val = 50)

names(post_comp_ecx_MN)
#"posterior_list" "posterior_data" "diff_list"      "diff_data"      "prob_diff"   

#Plot of posterior estimates of EC50s
post_estimates.1mn.p <- ggplot(data = post_comp_ecx_MN$posterior_data, mapping = aes(x = value)) + 
  theme_classic() +
  geom_density(mapping = aes(group = model, colour = model, fill = model), alpha = 0.3, show.legend = TRUE) +
  labs(x = "1-methylnaphthalene"~({mu*g~L^-1}), y = "") +
  scale_x_continuous(breaks = sqrt(c(0, 100, 1000, 4000)),
                     labels = c("0", "100", "1000", "4000"), limits = c(0, 68)) +
  theme(legend.position = c(0.8, 0.8)) 

post_estimates.1mn.p

post_comp_ecx_MN$prob_diff

# comparison      prob
# 1 T7d-Recovery 0.2911614

save(MN_7d_ecx, MN_7drec_ecx, naph_7d_ecx, naph_7drec_ecx, tol_7d_ecx, tol_7drec_ecx, file = "Post_estimates_new.RData")
load("Post_estimates_new.RData")

#--All posterior plots together----

pCombinePosteriors.all = cowplot::plot_grid(post_estimates.tol.p, post_estimates.naph.p, post_estimates.1mn.p, ncol=3)
ggsave(filename="Posteriors_all_final.png", plot=pCombinePosteriors.all, height = 3.5, width = 7.5, units=c("in"), dpi=300)
