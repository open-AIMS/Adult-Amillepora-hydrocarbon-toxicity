#---------Load packages----------
require(cmdstanr)
set_cmdstan_path("C:/cmdstan")
options(brms.backend = "cmdstanr")
library(bayesnec)
library(brms)
require(graphics)

library(readxl)
library(ggplot2)
library(tidyverse)
library(dplyr)
library(cowplot)
library(DHARMa)

#---Growth Toluene----

Growth.tol.data <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\Surv_data.xlsx", 
                              sheet = "tol_growth") %>% 
  na.omit() %>%
  dplyr::mutate(sqrt.x = sqrt(T7d_tol),
                GrowthRate2 = GrowthRate_amended + 0.001) %>% #adding a very small number here since there are some 0 values which will mess up when using Gamma distribution
  data.frame()

set.seed(123)
Growth.tol.fit2 <- bnec(GrowthRate2 ~ crf((sqrt.x), model = "all"),
                        data=Growth.tol.data,
                        family =Gamma(link = "identity"),
                        control = list(adapt_delta = 0.99), iter = 10e3)

# Fitted models are: nec3param nec4param nechorme nechorme4 necsigm nechormepwr nechorme4pwr 
#ecxexp ecxsigm ecxwb1 ecxwb2 ecxwb1p3 ecxwb2p3 ecxll5 ecxll4 ecxll3 ecxhormebc4 ecxhormebc5

autoplot(Growth.tol.fit2, all_models = TRUE)

summary(Growth.tol.fit2)

rhat(Growth.tol.fit2, rhat_cutoff = 1.05)
#  $failed none

check_chains(Growth.tol.fit2, filename = "Output/Growth_tol2_all_chains")
#not happy with necsigm chains mixing - will remove from MANEC
check_priors(Growth.tol.fit2, filename = "Output/Growth_tol2_all_priors")

Growth.tol.fit2.amended <- amend(Growth.tol.fit2, drop = c("necsigm"))

#Get EC10 and EC50
Growth.tol.EC10 <- ecx(Growth.tol.fit2.amended, ecx_val = 10)
Growth.tol.EC10^2

Growth.tol.EC50 <- ecx(Growth.tol.fit2.amended, ecx_val = 50)
Growth.tol.EC50^2

#Growth.tol.p ----
Growth.tol.preds <- Growth.tol.fit2.amended$w_pred_vals$data
Growth.tol.pred.vals <- Growth.tol.fit2.amended$w_pred_vals

pred.Growth.tol <- data.frame(up = Growth.tol.pred.vals$data$Q97.5,
                              lw = Growth.tol.pred.vals$data$Q2.5, 
                              x = Growth.tol.pred.vals$data$x, 
                              y = Growth.tol.pred.vals$data$Estimate)

Growth.tol.p.use <-  ggplot() +
  geom_point(data = Growth.tol.data, aes(x = sqrt.x, y = GrowthRate_amended, alpha = 0.10), 
             position = position_jitter(width = 1, height = 0), size = 1)

Growth.tol.p <- Growth.tol.p.use +
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = Growth.tol.EC10), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = Growth.tol.EC50), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue"), name = "") +
  geom_line(data = Growth.tol.preds, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = Growth.tol.preds, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = Growth.tol.preds, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "Toluene"~({mu*g~L^-1}), y = "") + 
  scale_x_continuous(breaks = sqrt(c(0, 1000, 3000, 10000, 30000)), 
                     labels = c("0", "1000", "3000", "10000", "30000")) +
  labs(title = "A)") +
  coord_cartesian(xlim = c(-1,173), ylim=c(0, 10)) + 
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.Growth.tol$x, ymin = pred.Growth.tol$lw, ymax = pred.Growth.tol$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 13))  
Growth.tol.p

save( Growth.tol.fit2, Growth.tol.fit2.amended, Growth.tol.EC10, Growth.tol.EC50, Growth.tol.preds, Growth.tol.pred.vals, 
      file = "Growth.tol2.RData")
load("Growth.tol2.RData")

#---Growth Naph ---- 
Growth.naph.dat <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\Surv_data.xlsx", 
                              sheet = "naph_growth") %>% 
  na.omit() %>%
  dplyr::mutate(x = sqrt(T7d_naph),
                GrowthRate2 = GrowthRate_amended + 0.001) %>% #adding a very small number here since there are some 0 values which will mess up when using Gamma distribution
  data.frame()

set.seed(123)
Growth.naph.fit2 <- bnec(GrowthRate2 ~ crf((x), model = "all"),
                         data=Growth.naph.dat,
                         family =Gamma(link = "identity"),
                         control = list(adapt_delta = 0.99), iter = 10e3)

#Fitted models are: nec3param nec4param nechorme nechorme4 necsigm nechormepwr nechorme4pwr 
#ecxexp ecxsigm ecx4param ecxwb1 ecxwb1p3 ecxwb2p3 ecxll4 ecxll3 ecxhormebc4

autoplot(Growth.naph.fit2, all_models = TRUE)

summary(Growth.naph.fit2)

rhat(Growth.naph.fit2, rhat_cutoff = 1.05)
#  $failed none

check_chains(Growth.naph.fit2, filename = "Output/Growth_naph_2_all_chains")
#all chain mixing looks good

check_priors(Growth.naph.fit2, filename = "Output/Growth_naph_2_all_priors")

#Thresholds

#Get EC10 and EC50
Growth.naph.EC10.2 <- ecx(Growth.naph.fit2, ecx_val = 10)
Growth.naph.EC10.2^2

Growth.naph.EC50.2 <- ecx(Growth.naph.fit2, ecx_val = 50)
Growth.naph.EC50.2^2

#Growth.naph.p----

Growth.naph.preds2 <- Growth.naph.fit2$w_pred_vals$data
Growth.naph.pred.vals2 <- Growth.naph.fit2$w_pred_vals

pred.Growth.naph2 <- data.frame(up = Growth.naph.pred.vals2$data$Q97.5,
                                lw = Growth.naph.pred.vals2$data$Q2.5, 
                                x = Growth.naph.pred.vals2$data$x, 
                                y = Growth.naph.pred.vals2$data$Estimate)

Growth.naph.p2 <- ggplot() +
  geom_point(data = Growth.naph.dat, aes(x = x, y = GrowthRate_amended, alpha = 0.10), 
             position = position_jitter(width = 1, height = 0), size = 1)

Growth.naph.p <- Growth.naph.p2 + 
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = Growth.naph.EC10.2), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = Growth.naph.EC50.2), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue"), name = "") +
  geom_line(data = Growth.naph.preds2, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = Growth.naph.preds2, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = Growth.naph.preds2, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "Naphthalene"~({mu*g~L^-1}), y = "Growth Rate "~({mm^2~d^-1})) + 
  scale_x_continuous(breaks = sqrt(c(0, 300, 1000, 3000, 10000)), 
                     labels = c("0", "300", "1000", "3000", "10000")) +
  labs(title = "B)") +
  coord_cartesian(xlim = c(-1,103), ylim=c(0, 15)) + 
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.Growth.naph2$x, ymin = pred.Growth.naph2$lw, ymax = pred.Growth.naph2$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 13))  

Growth.naph.p

save(Growth.naph.fit2, Growth.naph.EC10.2, Growth.naph.EC50.2, Growth.naph.preds2, Growth.naph.pred.vals2, 
     file = "Output/Growth.naph2.RData")
load("Output/Growth.naph2.RData")

#---Growth 1-MN-----

Growth.1mn.dat <- read_excel("C:\\Users\\fflores\\OneDrive - Australian Institute of Marine Science\\Documents\\Florita R\\single PAH\\Surv_data.xlsx", 
                             sheet = "1mn_growth") %>% 
  na.omit() %>%
  dplyr::mutate(x = sqrt(T7d_1mn), 
                GrowthRate2 = GrowthRate_amended + 0.001) %>% #adding a very small number here since there are some 0 values which will mess up when using Gamma distribution
  data.frame()

set.seed(123)
Growth.1mn.fit2 <- bnec(GrowthRate2 ~ crf((x), model = "all"),
                        data=Growth.1mn.dat,
                        family =Gamma(link = "identity"),
                        control = list(adapt_delta = 0.99), iter = 10e3)
#Fitted models are: nec3param nec4param nechorme nechorme4 necsigm nechormepwr nechorme4pwr ecxexp 
#ecxsigm ecx4param ecxwb1 ecxwb2 ecxwb1p3 ecxwb2p3 ecxll5 ecxll4 ecxll3 ecxhormebc4

autoplot(Growth.1mn.fit2, all_models = TRUE)

summary(Growth.1mn.fit2)

rhat(Growth.1mn.fit2, rhat_cutoff = 1.05)
#  necsigm failed

check_chains(Growth.1mn.fit2, filename = "Output/Growth_1mn_2_all_chains")
#chain mixing 

check_priors(Growth.1mn.fit2, filename = "Output/Growth_1mn_2_all_priors")

Growth.1mn.fit2.amended <- amend(Growth.1mn.fit2, drop = c("necsigm"))

#Get EC10 and EC50
Growth.1mn.EC10 <- ecx(Growth.1mn.fit2.amended, ecx_val = 10)
Growth.1mn.EC10^2

Growth.1mn.EC50 <- ecx(Growth.1mn.fit2.amended, ecx_val = 50)
Growth.1mn.EC50^2

#Growth.1mn.p-----
Growth.1mn.preds <- Growth.1mn.fit2.amended$w_pred_vals$data
Growth.1mn.pred.vals <- Growth.1mn.fit2.amended$w_pred_vals

pred.Growth.1mn <- data.frame(up = Growth.1mn.pred.vals$data$Q97.5,
                              lw = Growth.1mn.pred.vals$data$Q2.5, 
                              x = Growth.1mn.pred.vals$data$x, 
                              y = Growth.1mn.pred.vals$data$Estimate)

Growth.1mn.p.use <- ggplot() +
  geom_point(data = Growth.1mn.dat, aes(x = x, y = GrowthRate_amended, alpha = 0.10), 
             position = position_jitter(width = 1, height = 0), size = 1)


Growth.1mn.p <- Growth.1mn.p.use + 
  theme_classic() + 
  geom_vline(mapping = aes(xintercept = Growth.1mn.EC10), color = "green4",
             linetype = c(1,3,3), key_glyph = "path") + 
  geom_vline(mapping = aes(xintercept = Growth.1mn.EC50), color = "blue",
             linetype = c(1,3,3), key_glyph = "path") + 
  scale_color_manual(values = c("EC10" = "green4", "EC50" = "blue"), name = "") +
  geom_line(data = Growth.1mn.preds, mapping = aes(x = x, y = Estimate),
            colour = "black", linetype = 1) +
  geom_line(data = Growth.1mn.preds, mapping = aes(x = x, y = Q2.5),
            colour = "grey", linetype = 1) +
  geom_line(data = Growth.1mn.preds, mapping = aes(x = x, y = Q97.5),
            colour = "grey", linetype = 1) +
  labs(x = "1-methylnaphthalene"~({mu*g~L^-1}), y = "") + 
  scale_x_continuous(breaks = sqrt(c(0, 100, 300, 1000, 3000)), 
                     labels = c("0", "100", "300", "1000", "3000")) +
  labs(title = "C)") +
  coord_cartesian(xlim = c(-1,57), ylim=c(0, 5.2)) + 
  theme(legend.position = "none") +
  geom_ribbon(aes(x = pred.Growth.1mn$x, ymin = pred.Growth.1mn$lw, ymax = pred.Growth.1mn$up, fill = "gray"), alpha = 0.3) + 
  scale_fill_manual(values = c("gray")) +
  theme(axis.title.y = element_text(size = 12),
        axis.title.x = element_text(size=11),
        axis.text = element_text(size = 9), 
        strip.text.x = element_blank(),
        plot.title = element_text(size = 13))  

Growth.1mn.p

save(Growth.1mn.fit2, Growth.1mn.fit2.amended, Growth.1mn.EC10, Growth.1mn.EC50, Growth.1mn.preds, Growth.1mn.pred.vals,
     file = "Output/Growth.1mn.v2.RData")
load("Output/Growth.1mn.v2.RData")

#All figures combined -----
# cowplot
pCombine = cowplot::plot_grid(Growth.tol.p, Growth.naph.p, Growth.1mn.p, ncol=1, align = "hv")

ggsave(filename="Output/GrowthRate_all.pdf", plot=pCombine, height = 7, width=3.25, units=c("in"), dpi=300)
ggsave(filename="Output/GrowthRate_all.png", plot=pCombine, height = 5.5, width= 3.25, units=c("in"), dpi=300)

